#!/usr/bin/env bash
# Redraws the ten figures (about 1 minute) from the shipped result files in outputs/.
set -euo pipefail
cd "$(dirname "$0")/code"
python 06_figures.py ../data/click_fraud_dataset.csv ../outputs ../figures_rerun
