"""Step 3b. What the DBSCAN clusters of the parameter grid represent (regime U, all twelve inputs).

For every grid configuration of step 3 (minPts x eps rule) the training clicks are clustered again and each cluster is
described by its size, its fraud rate and the input whose standardised mean deviates most from zero (the input that
separates the cluster from the rest). The fraud rate is computed only to describe the clusters; it is not used by DBSCAN.

Usage: python 03b_dbscan_clusters.py <data.csv> <ablations.json> <out_dir>
"""
import json, os, sys
import numpy as np, pandas as pd
from cf_lib import *

DATA, ABL, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
df = load(DATA); y = df['is_fraudulent'].values.astype(int)
tr, ca, te = chrono_split(len(df))
P = Prep(FEATURES['FULL']).fit(df.iloc[tr]); Xtr = P.transform(df.iloc[tr]); ytr = y[tr]
G = pd.DataFrame(json.load(open(ABL))['dbscan_grid'])
G = G[(G.regime == 'U') & (G.eps_rule != 'orig')]
MIN_N = 20
rows, clusters = [], []
for _, g in G.iterrows():
    m = DBSCAN_(0, eps=float(g.eps), min_samples=int(g.min_samples)).fit(Xtr); lab = m.train_labels
    assert m.n_clusters == g.n_clusters
    for c in sorted(set(lab[lab >= 0])):
        idx = lab == c; mz = Xtr[idx].mean(axis=0); j = int(np.argmax(np.abs(mz)))
        clusters.append({'min_samples': int(g.min_samples), 'eps_rule': g.eps_rule, 'cluster': int(c), 'n': int(idx.sum()),
                         'fraud_rate': float(ytr[idx].mean()), 'defining_input': P.keep[j], 'defining_input_mean_z': float(mz[j]),
                         'silhouette_of_clustering': None if pd.isna(g.silhouette_non_noise) else float(g.silhouette_non_noise)})
C = pd.DataFrame(clusters)
big = C[C.n >= MIN_N]
default = C[(C.min_samples == 2 * Xtr.shape[1]) & (C.eps_rule == 'knee')]
best_sil = G.loc[G.silhouette_non_noise.astype(float).idxmax()]
best_cl = C[(C.min_samples == best_sil.min_samples) & (C.eps_rule == best_sil.eps_rule)]
summary = {
    'base_rate_train': float(ytr.mean()), 'min_cluster_size_for_summary': MIN_N,
    'n_clusters_ge_min': int(len(big)), 'fraud_rate_range_clusters_ge_min': [float(big.fraud_rate.min()), float(big.fraud_rate.max())],
    'defining_inputs_clusters_ge_min': big.defining_input.value_counts().to_dict(),
    'default_config': default.to_dict('records'),
    'max_silhouette_config': {'min_samples': int(best_sil.min_samples), 'eps_rule': best_sil.eps_rule, 'silhouette': float(best_sil.silhouette_non_noise),
                              'clusters': best_cl.to_dict('records')},
}
json.dump({'summary': summary, 'clusters': clusters}, open(os.path.join(OUT, 'dbscan_clusters.json'), 'w'), indent=1)
print(json.dumps(summary, indent=1))
