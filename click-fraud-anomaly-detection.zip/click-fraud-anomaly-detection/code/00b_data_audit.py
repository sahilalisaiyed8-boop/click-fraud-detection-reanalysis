"""Step 0b. Data audit (reviewer 2, comment 4): labelling rule, marginal distributions, independence, identifiers.
The generator of the public dataset is not published; this script recovers its observable rules from the data.
Usage: python 00b_data_audit.py <data.csv> <out_dir>
"""
import json, os, sys
import numpy as np, pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
df = pd.read_csv(DATA); y = df['is_fraudulent'].values
ts = pd.to_datetime(df['timestamp']); df['hour_of_day'] = ts.dt.hour; df['day_of_week'] = ts.dt.dayofweek
A = {'n': int(len(df)), 'n_columns': int(df.shape[1]), 'missing_cells': int(df.isna().sum().sum()), 'duplicate_rows': int(df.duplicated().sum()),
     'fraud_rate': float(y.mean()), 'n_fraud': int(y.sum()), 'date_range': [str(ts.min()), str(ts.max())],
     'unique': {c: int(df[c].nunique()) for c in ['click_id', 'user_id', 'ip_address', 'referrer_url', 'page_url']}}
b = df['bot_likelihood_score']
A['labelling_rule'] = {'rule': 'is_fraudulent = 1 if bot_likelihood_score > 0.75 else 0', 'agreement': int(((b > 0.75).astype(int) == y).sum()),
                       'bot_values_distinct': int(b.nunique()), 'bot_resolution': 0.01,
                       'max_bot_normal': float(b[y == 0].max()), 'min_bot_fraud': float(b[y == 1].min())}
cv = StratifiedKFold(5, shuffle=True, random_state=0)
A['depth1_tree_cv_accuracy_bot_only'] = float(cross_val_score(DecisionTreeClassifier(max_depth=1), df[['bot_likelihood_score']], y, cv=cv).mean())
num = ['bot_likelihood_score', 'click_duration', 'scroll_depth', 'mouse_movement', 'keystrokes_detected', 'click_frequency', 'time_since_last_click',
       'VPN_usage', 'proxy_usage', 'hour_of_day', 'day_of_week']
rep = df['device_ip_reputation'].map({'Good': 0, 'Suspicious': 1, 'Bad': 2})
uni = {c: float(roc_auc_score(y, df[c])) for c in num}
uni['ip_reputation (ordinal)'] = float(roc_auc_score(y, rep))
A['univariate_auc'] = uni
A['class_means'] = {c: [float(df.loc[y == 0, c].mean()), float(df.loc[y == 1, c].mean())] for c in num}
A['mannwhitney_p_vs_label'] = {c: float(stats.mannwhitneyu(df.loc[y == 1, c], df.loc[y == 0, c]).pvalue) for c in num if c != 'bot_likelihood_score'}
cats = ['device_type', 'browser', 'operating_system', 'ad_position', 'device_ip_reputation']
A['chi2_p_vs_label'] = {c: float(stats.chi2_contingency(pd.crosstab(df[c], y))[1]) for c in cats}
A['fraud_rate_by_category'] = {c: df.groupby(c)['is_fraudulent'].mean().round(4).to_dict() for c in cats + ['VPN_usage', 'proxy_usage']}
C = df[num].corr(method='spearman').values; iu = np.triu_indices(len(num), 1)
A['max_abs_spearman_between_inputs'] = float(np.abs(C[iu]).max())
# marginal shapes
marg = {}
for c, lo, hi in [('scroll_depth', 0, 99), ('mouse_movement', 0, 499), ('keystrokes_detected', 0, 49), ('click_frequency', 1, 9), ('time_since_last_click', 1, 599)]:
    v = df[c].values; obs = np.bincount(v - lo, minlength=hi - lo + 1)
    marg[c] = {'min': int(v.min()), 'max': int(v.max()), 'shape': 'integer, approximately uniform', 'chi2_uniform_p': float(stats.chisquare(obs).pvalue)}
bc = np.round(b * 100).astype(int)
marg['bot_likelihood_score'] = {'min': float(b.min()), 'max': float(b.max()), 'shape': 'uniform on [0, 1], 0.01 steps', 'chi2_uniform_p': float(stats.chisquare(np.bincount(bc, minlength=101)).pvalue)}
cd = df['click_duration']
marg['click_duration'] = {'min': float(cd.min()), 'max': float(cd.max()), 'mean': float(cd.mean()), 'sd': float(cd.std()), 'shape': 'exponential',
                          'ks_exponential_p': float(stats.kstest(cd, 'expon', args=(0, cd.mean())).pvalue)}
sec = (ts - ts.min()).dt.total_seconds()
marg['timestamp'] = {'shape': 'uniform over one year', 'ks_uniform_p': float(stats.kstest(sec / sec.max(), 'uniform').pvalue)}
marg['VPN_usage'] = {'rate': float(df['VPN_usage'].mean())}; marg['proxy_usage'] = {'rate': float(df['proxy_usage'].mean())}
marg['device_ip_reputation'] = df['device_ip_reputation'].value_counts(normalize=True).round(4).to_dict()
A['marginals'] = marg
# IQR rule of the submitted study (applied to the full sample)
cols = ['click_duration', 'scroll_depth', 'mouse_movement', 'keystrokes_detected', 'bot_likelihood_score']
keep = np.ones(len(df), bool); lim = {}
for c in cols:
    q1, q3 = df[c].quantile([0.25, 0.75]); i = q3 - q1; lim[c] = [float(q1 - 1.5 * i), float(q3 + 1.5 * i)]
    keep &= (df[c] >= q1 - 1.5 * i).values & (df[c] <= q3 + 1.5 * i).values
A['iqr_submitted'] = {'limits': lim, 'removed': int((~keep).sum()), 'fraud_rate_removed': float(y[~keep].mean()), 'fraud_rate_kept': float(y[keep].mean()),
                      'n_kept': int(keep.sum()), 'n_fraud_kept': int(y[keep].sum()), 'n_normal_kept': int((y[keep] == 0).sum())}
json.dump(A, open(os.path.join(OUT, 'audit.json'), 'w'), indent=1, default=float)
print(json.dumps(A, indent=1, default=float))
