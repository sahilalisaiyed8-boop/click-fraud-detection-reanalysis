"""Step 6. All figures of the revised manuscript, drawn only from the saved outputs of steps 1-5.

Every figure is drawn at its final printed width (160 mm, the width at which it is placed in the manuscript), so the
font sizes set below are the sizes that appear on the page (7-8.5 pt). Colours follow the colour-blind-safe palette of
Wong (2011); every detector keeps the same colour, line style and marker in all figures.

Outputs per figure: PNG (300 dpi, used in the manuscript file), TIFF (600 dpi, LZW) and PDF (vector, fonts embedded).

Usage: python 06_figures.py <data.csv> <out_root> <fig_dir> [fig1 ... fig10]
"""
import io, json, os, pickle, sys
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, Patch, Circle
from PIL import Image
from scipy.stats import rankdata
from sklearn.metrics import roc_curve, precision_recall_curve
from cf_lib import load, chrono_split, ORDER, safe_auc

DATA, OUTR, FIG = sys.argv[1], sys.argv[2], sys.argv[3]
WHICH = set(sys.argv[4:]) or {'all'}
os.makedirs(FIG, exist_ok=True)

MM = 1 / 25.4
WIDTH = 160 * MM                                   # printed width of every figure
plt.rcParams.update({
    'font.family': 'DejaVu Serif', 'mathtext.fontset': 'dejavuserif',
    'font.size': 7.5, 'axes.titlesize': 8, 'axes.labelsize': 7.5, 'xtick.labelsize': 7, 'ytick.labelsize': 7,
    'legend.fontsize': 7, 'legend.title_fontsize': 7, 'legend.frameon': False, 'legend.handlelength': 2.2,
    'legend.handletextpad': 0.5, 'legend.columnspacing': 1.2, 'legend.borderaxespad': 0.3, 'legend.labelspacing': 0.35,
    'axes.linewidth': 0.6, 'axes.edgecolor': '#222222', 'axes.labelcolor': '#111111', 'axes.titlepad': 4, 'axes.labelpad': 2.5,
    'axes.spines.top': False, 'axes.spines.right': False,
    'xtick.major.width': 0.6, 'ytick.major.width': 0.6, 'xtick.major.size': 2.5, 'ytick.major.size': 2.5,
    'xtick.major.pad': 2, 'ytick.major.pad': 2, 'xtick.color': '#222222', 'ytick.color': '#222222',
    'grid.color': '#E3E3E3', 'grid.linewidth': 0.5, 'lines.linewidth': 1.1, 'lines.markersize': 3,
    'patch.linewidth': 0.6, 'hatch.linewidth': 0.5, 'figure.dpi': 150, 'savefig.dpi': 300,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})

# Wong (2011) palette; grey for DBSCAN. Classical detectors solid (DBSCAN dotted), recent detectors dashed.
COL = {'IF': '#E69F00', 'LOF': '#56B4E9', 'OCSVM': '#009E73', 'DBSCAN': '#7A7A7A',
       'AE': '#D55E00', 'ECOD': '#0072B2', 'DSVDD': '#CC79A7', 'TRF': '#000000'}
DASH = (0, (4.0, 1.6))
LS = {'IF': '-', 'LOF': '-', 'OCSVM': '-', 'DBSCAN': (0, (1.0, 1.4)), 'AE': '-', 'ECOD': DASH, 'DSVDD': DASH, 'TRF': DASH}
MK = {'IF': 'o', 'LOF': 's', 'OCSVM': '^', 'DBSCAN': 'D', 'AE': 'v', 'ECOD': 'P', 'DSVDD': 'X', 'TRF': 'h'}
SHORT = {'IF': 'IF', 'LOF': 'LOF', 'OCSVM': 'OCSVM', 'DBSCAN': 'DBSCAN', 'AE': 'AE', 'ECOD': 'ECOD', 'DSVDD': 'Deep SVDD', 'TRF': 'Transformer'}
REG = {'U': 'Unlabelled training (U)', 'S': 'Clean-normal training (S)'}
NORMAL, FRAUD = '#56B4E9', '#D55E00'
REF = dict(color='#555555', lw=0.8, ls='-.')        # chance / base-rate / flag-all reference lines (dash-dotted)

df = load(DATA); y = df['is_fraudulent'].values.astype(int)
tr, ca, te = chrono_split(len(df))


def want(n): return 'all' in WHICH or n in WHICH


def ptitle(ax, letter, text='', **kw):
    """Panel title: bold letter, plain text, left-aligned."""
    ax.set_title(r'$\mathbf{(' + letter + r')}$' + ('  ' + text if text else ''), loc='left', **kw)


def save(fig, name):
    """PNG 300 dpi (manuscript), TIFF 600 dpi LZW (submission), PDF vector (submission); RGB, white background."""
    for ext, dpi in (('png', 300), ('tif', 600)):
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=dpi, bbox_inches='tight', pad_inches=0.03, facecolor='white')
        im = Image.open(buf).convert('RGB')
        if ext == 'png':
            im.save(os.path.join(FIG, name + '.png'), dpi=(dpi, dpi), optimize=True)
        else:
            im.save(os.path.join(FIG, name + '.tif'), dpi=(dpi, dpi), compression='tiff_lzw')
    fig.savefig(os.path.join(FIG, name + '.pdf'), bbox_inches='tight', pad_inches=0.03, facecolor='white')
    w, h = fig.get_size_inches()
    plt.close(fig); print(f'saved {name}  ({w / MM:.0f} x {h / MM:.0f} mm drawing area)')


def check_inside(fig, pairs, tol=1.0):
    """Assert that every text lies inside its box (display coordinates); used for the diagram in Fig. 1."""
    fig.canvas.draw(); r = fig.canvas.get_renderer(); bad = []
    for box, texts in pairs:
        bb = box.get_window_extent(r)
        for t in texts:
            tb = t.get_window_extent(r)
            if tb.x0 < bb.x0 + tol or tb.x1 > bb.x1 - tol or tb.y0 < bb.y0 + tol or tb.y1 > bb.y1 - tol:
                bad.append(t.get_text()[:40])
    if bad:
        raise SystemExit('text outside its box: ' + '; '.join(bad))


# ------------------------------------------------------------------ Fig. 1 protocol diagram
if want('fig1'):
    fig = plt.figure(figsize=(WIDTH, 76 * MM)); ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 160); ax.set_ylim(0, 76); ax.axis('off')
    X0, GAP = 2.4, 4.6
    BW = (160 - 2 * X0 - 3 * GAP) / 4; BH = 31.0
    xs = [X0 + i * (BW + GAP) for i in range(4)]
    rows_y = [42.6, 2.4]
    BLUE, ORANGE, GREEN = ('#EAF2FA', '#0072B2'), ('#FDF1E3', '#C98900'), ('#E9F5EE', '#009E73')
    steps = [
        ('Data audit', '5,000 clicks, 21 fields\nLabel rule identified:\nfraud = 1 when the\nbot score exceeds 0.75\nAssociation and\ndistribution tests', BLUE),
        ('Time-ordered split', 'Train 60%\n(Feb–Sep 2024)\nCalibration 20%\n(Sep–Dec 2024)\nHeld-out test 20%\n(Dec 2024–Feb 2025)', BLUE),
        ('Feature construction', 'Per-click inputs only\nPast-only IP/user counts\nRare combinations from\ntraining counts\nScaler fitted on the\ntraining split', BLUE),
        ('Information regimes', 'U: all training clicks,\nno labels\nS: label-selected normal\nclicks (one-class)\nSame data for every\ndetector', ORANGE),
        ('Eight detectors', 'Isolation Forest,\nLOF, One-Class SVM,\nDBSCAN, autoencoder,\nECOD, Deep SVDD,\nTransformer', ORANGE),
        ('Operating points', 'Flag rates q = 1–50%\nfrom fitting-data scores\nF1-optimal threshold set\non the calibration split\nand applied unchanged\nto the test split', GREEN),
        ('Test-split evaluation', 'AUC-ROC and average\nprecision with 95%\nbootstrap CIs (B = 2,000)\nF1-score at thresholds\nPaired bootstrap tests\n10 repeated splits', GREEN),
        ('Robustness checks', 'Feature-set ablations\nIQR filter; DBSCAN grid\nHyper-parameters\nMonthly stability\nNeighbourhood mixing,\nt-SNE; computing time', GREEN)]
    pairs = []
    for i, (title, body, (fc, ec)) in enumerate(steps):
        x, yb = xs[i % 4], rows_y[i // 4]
        box = FancyBboxPatch((x, yb), BW, BH, boxstyle='round,pad=0,rounding_size=1.6', fc=fc, ec=ec, lw=0.8, zorder=1)
        ax.add_patch(box)
        ax.add_patch(Circle((x + 0.9, yb + BH - 0.9), 2.2, fc=ec, ec='white', lw=0.8, zorder=3))
        ax.text(x + 0.9, yb + BH - 0.95, str(i + 1), ha='center', va='center', fontsize=7, fontweight='bold', color='white', zorder=4)
        t1 = ax.text(x + BW / 2, yb + BH - 4.1, title, ha='center', va='center', fontsize=7.2, fontweight='bold', zorder=2)
        # body lines placed individually at a constant pitch (multi-line text spacing varies with glyph heights),
        # and the block centred vertically in the space below the title
        lines = body.split('\n'); pitch = 3.15
        top_area, bottom_area = yb + BH - 6.6, yb + 1.0
        y0 = (top_area + bottom_area) / 2 + (len(lines) - 1) * pitch / 2
        tl = [ax.text(x + BW / 2, y0 - n * pitch, ln, ha='center', va='center', fontsize=7.0, color='#111111', zorder=2) for n, ln in enumerate(lines)]
        pairs.append((box, [t1] + tl))
    ap = dict(arrowstyle='-|>,head_length=0.45,head_width=0.22', color='#333333', lw=0.8, shrinkA=0, shrinkB=0)
    for row in range(2):
        yc = rows_y[row] + BH / 2
        for i in range(3):
            ax.annotate('', xy=(xs[i + 1] - 0.5, yc), xytext=(xs[i] + BW + 0.5, yc), arrowprops=ap)
    # elbow connector from step 4 (end of the first row) to step 5 (start of the second row)
    ymid = (rows_y[0] + rows_y[1] + BH) / 2
    xa, xb = xs[3] + BW / 2, xs[0] + BW / 2
    ax.plot([xa, xa, xb], [rows_y[0] - 0.3, ymid, ymid], color='#333333', lw=0.8, solid_capstyle='butt', solid_joinstyle='miter')
    ax.annotate('', xy=(xb, rows_y[1] + BH + 0.5), xytext=(xb, ymid), arrowprops=ap)
    check_inside(fig, pairs)
    save(fig, 'Fig1_protocol')

# ------------------------------------------------------------------ Fig. 2 data audit
if want('fig2'):
    aud = json.load(open(os.path.join(OUTR, 'audit', 'audit.json')))
    fig = plt.figure(figsize=(WIDTH, 100 * MM))
    TOP_Y, TOP_H, BOT_Y, BOT_H = 0.585, 0.355, 0.095, 0.3
    ax = fig.add_axes([0.075, TOP_Y, 0.40, TOP_H])
    bins = np.arange(-0.005, 1.015, 0.01)
    ax.hist(df.loc[y == 0, 'bot_likelihood_score'], bins=bins, color=NORMAL, lw=0, label='Normal (label 0)')
    ax.hist(df.loc[y == 1, 'bot_likelihood_score'], bins=bins, color=FRAUD, lw=0, label='Fraudulent (label 1)')
    ax.axvline(0.755, color='k', ls='--', lw=0.8)
    ax.set_ylim(0, 112); ax.set_xlim(-0.02, 1.02)
    ax.text(0.735, 78, 'label = 1 if and only if\nscore > 0.75 (all 5,000 clicks)', ha='right', va='center', fontsize=6.8, linespacing=1.2)
    ax.set_xlabel('Bot-likelihood score'); ax.set_ylabel('Clicks per 0.01 bin')
    ax.legend(loc='upper left', ncol=1, handlelength=1.2, borderaxespad=0.1)
    ptitle(ax, 'a', 'Bot-likelihood score by class')
    ax = fig.add_axes([0.665, TOP_Y, 0.325, TOP_H])
    NM = {'bot_likelihood_score': 'Bot-likelihood score', 'ip_reputation (ordinal)': 'Device–IP reputation', 'time_since_last_click': 'Time since last click',
          'click_duration': 'Click duration', 'keystrokes_detected': 'Keystrokes detected', 'day_of_week': 'Day of week', 'proxy_usage': 'Proxy usage',
          'click_frequency': 'Click frequency', 'hour_of_day': 'Hour of day', 'VPN_usage': 'VPN usage', 'mouse_movement': 'Mouse movement', 'scroll_depth': 'Scroll depth'}
    ua = pd.Series(aud['univariate_auc']).sort_values()
    names = [NM.get(i, i) for i in ua.index]; yy = np.arange(len(ua))
    cols = [FRAUD if v > 0.9 else '#0072B2' for v in ua.values]
    ax.hlines(yy, 0.5, ua.values, color=cols, lw=1.0)
    ax.scatter(ua.values, yy, color=cols, s=14, zorder=3, lw=0)
    ax.axvline(0.5, **REF)
    for i, v in enumerate(ua.values):
        ax.text(max(v, 0.5) + 0.013, i, f'{v:.3f}', va='center', ha='left', fontsize=6.6)
    ax.set_yticks(yy); ax.set_yticklabels(names); ax.tick_params(axis='y', length=0)
    ax.set_xlim(0.45, 1.1); ax.set_xticks([0.5, 0.6, 0.7, 0.8, 0.9, 1.0]); ax.set_ylim(-0.7, len(ua) - 0.3)
    ax.set_xlabel('AUC-ROC for the fraud label')
    ax.grid(axis='x'); ax.set_axisbelow(True)
    ptitle(ax, 'b', 'Univariate AUC-ROC')
    for j, (c, lab, ttl) in enumerate([('click_duration', 'Click duration (s)', 'Click duration'), ('scroll_depth', 'Scroll depth (%)', 'Scroll depth'),
                                       ('mouse_movement', 'Mouse movement', 'Mouse movement'), ('time_since_last_click', 'Time since last click (s)', 'Time since last click')]):
        ax = fig.add_axes([0.075 + j * (0.2025 + 0.0325), BOT_Y, 0.2025, BOT_H]); b = np.histogram_bin_edges(df[c], bins=20)
        ax.hist(df.loc[y == 0, c], bins=b, density=True, color=NORMAL, lw=0, label='Normal')
        ax.hist(df.loc[y == 1, c], bins=b, density=True, histtype='step', color=FRAUD, lw=1.0, label='Fraudulent')
        ax.set_xlabel(lab); ax.set_yticks([]); ax.spines['left'].set_visible(False)
        ptitle(ax, chr(99 + j), ttl)
        if j == 0:
            ax.set_ylabel('Density'); ax.legend(loc='upper right', handlelength=1.4)
    save(fig, 'Fig2_data_audit')

# ------------------------------------------------------------------ Fig. 3/4 ROC and PR on the test split
if want('fig3') or want('fig4'):
    S = pickle.load(open(os.path.join(OUTR, 'main', 'main_scores.pkl'), 'rb'))['scores']
    R = {(r['featureset'], r['regime'], r['model']): r for r in json.load(open(os.path.join(OUTR, 'main', 'main_results.json')))['rows']}
    for kind in ['roc', 'pr']:
        if not want('fig3' if kind == 'roc' else 'fig4'):
            continue
        H = 104 * MM
        fig = plt.figure(figsize=(WIDTH, H))
        side = 61 * MM; aw, ah = side / WIDTH, side / H; bottom = 0.27
        axs = [fig.add_axes([0.08, bottom, aw, ah]), fig.add_axes([0.08 + aw + 0.125, bottom, aw, ah])]
        for ax, reg, letter in zip(axs, ['U', 'S'], 'ab'):
            for k in ORDER:
                s = np.asarray(S[('FULL', reg, k)]['test'], float); yt = S[('FULL', reg, k)]['y_test']
                s = np.where(np.isfinite(s), s, np.nanmax(s[np.isfinite(s)]) + 1)
                r = R[('FULL', reg, k)]
                if kind == 'roc':
                    fpr, tpr, _ = roc_curve(yt, s)
                    ax.plot(fpr, tpr, color=COL[k], ls=LS[k], lw=1.05, label=f"{SHORT[k]} ({r['auc']:.3f})")
                else:
                    p, rc, _ = precision_recall_curve(yt, s)
                    keep = rc > 0                     # drop the zero-recall points (sklearn's appended (0, 1) point and thresholds with no true positive)
                    ax.plot(rc[keep], p[keep], color=COL[k], ls=LS[k], lw=1.05, label=f"{SHORT[k]} ({r['ap']:.3f})", drawstyle='steps-post')
            if kind == 'roc':
                ax.plot([0, 1], [0, 1], **REF)
                ax.set_xlabel('False positive rate'); ax.set_ylabel('True positive rate')
                title = 'AUC-ROC'
            else:
                ax.axhline(yt.mean(), **REF, label=f'Base rate ({yt.mean():.3f})')
                ax.set_xlabel('Recall'); ax.set_ylabel('Precision')
                title = 'Average precision'
            ax.set_xlim(-0.01, 1.01); ax.set_ylim(-0.01, 1.01)
            ax.set_xticks(np.linspace(0, 1, 6)); ax.set_yticks(np.linspace(0, 1, 6))
            ax.grid(True); ax.set_axisbelow(True)
            ax.legend(title=title, loc='upper center', bbox_to_anchor=(0.5, -0.145), ncol=2, alignment='left', columnspacing=1.2, handlelength=2.0)
            ptitle(ax, letter, REG[reg])
        save(fig, 'Fig3_roc_test' if kind == 'roc' else 'Fig4_pr_test')

# ------------------------------------------------------------------ Fig. 5 AUC with CIs across feature sets, plus repeated splits
if want('fig5'):
    R = json.load(open(os.path.join(OUTR, 'main', 'main_results.json')))['rows']
    rep = pd.read_csv(os.path.join(OUTR, 'repeats', 'repeats_long.csv'))
    fig, axs = plt.subplots(1, 2, figsize=(WIDTH, 82 * MM), sharey=True)
    fig.subplots_adjust(left=0.075, right=0.99, top=0.92, bottom=0.27, wspace=0.07)
    fsc = {'FULL': '#D55E00', 'NOBOT': '#0072B2', 'BEHAV': '#009E73'}
    fmk = {'FULL': 'o', 'NOBOT': 's', 'BEHAV': '^'}
    lab = {'FULL': 'All inputs (incl. bot score)', 'NOBOT': 'Without bot score', 'BEHAV': 'Behavioural inputs only'}
    for ax, reg, letter in zip(axs, ['U', 'S'], 'ab'):
        for i in range(len(ORDER)):
            if i % 2 == 1:
                ax.axvspan(i - 0.5, i + 0.5, color='#F4F4F4', lw=0, zorder=0)
        ax.axhline(0.5, **REF, zorder=1)
        for j, fs in enumerate(['FULL', 'NOBOT', 'BEHAV']):
            xs_ = np.arange(len(ORDER)) + (j - 1) * 0.26
            rr = {r['model']: r for r in R if r['featureset'] == fs and r['regime'] == reg}
            yv = np.array([rr[k]['auc'] for k in ORDER])
            lo = yv - np.array([rr[k]['auc_ci'][0] for k in ORDER]); hi = np.array([rr[k]['auc_ci'][1] for k in ORDER]) - yv
            if fs in ('FULL', 'NOBOT'):
                for i, k in enumerate(ORDER):
                    v = rep[(rep.featureset == fs) & (rep.regime == reg) & (rep.model == k)]['auc'].values
                    ax.scatter(np.full(len(v), xs_[i] + 0.1), v, s=3.5, color=fsc[fs], alpha=0.45, lw=0, zorder=2)
            ax.errorbar(xs_, yv, yerr=[lo, hi], fmt=fmk[fs], ms=3.6, mfc=fsc[fs], mec='white', mew=0.4, color=fsc[fs], ecolor=fsc[fs],
                        elinewidth=0.9, capsize=1.6, capthick=0.9, lw=0, zorder=3, label=lab[fs])
        ax.set_xticks(range(len(ORDER))); ax.set_xticklabels([SHORT[k] for k in ORDER], rotation=35, ha='right', rotation_mode='anchor')
        ax.tick_params(axis='x', length=0); ax.set_xlim(-0.6, len(ORDER) - 0.4)
        ax.set_ylim(0.38, 1.0); ax.grid(axis='y'); ax.set_axisbelow(True)
        ptitle(ax, letter, REG[reg])
    axs[0].set_ylabel('Test AUC-ROC')
    h, l = axs[0].get_legend_handles_labels()
    h.append(Line2D([], [], ls='', marker='o', ms=2.2, color='#777777', alpha=0.7)); l.append('Repeated stratified splits (10 per setting)')
    fig.legend(h, l, loc='lower center', ncol=2, bbox_to_anchor=(0.53, 0.0), columnspacing=2.0, handletextpad=0.4)
    save(fig, 'Fig5_auc_overview')

# ------------------------------------------------------------------ Fig. 6 what the detectors learned: score vs bot score
if want('fig6'):
    S = pickle.load(open(os.path.join(OUTR, 'main', 'main_scores.pkl'), 'rb'))['scores']
    bot = df['bot_likelihood_score'].values[te]; yt = y[te]
    fig, axs = plt.subplots(2, 4, figsize=(WIDTH, 88 * MM), sharex=True, sharey=True)
    fig.subplots_adjust(left=0.105, right=0.99, top=0.93, bottom=0.17, wspace=0.09, hspace=0.3)
    for i, reg in enumerate(['U', 'S']):
        for j, k in enumerate(['AE', 'LOF', 'ECOD', 'IF']):
            ax = axs[i, j]; s = np.asarray(S[('FULL', reg, k)]['test'], float); r = rankdata(s) / len(s)
            ax.scatter(bot[yt == 0], r[yt == 0], s=1.6, color=NORMAL, alpha=0.75, lw=0, rasterized=True)
            ax.scatter(bot[yt == 1], r[yt == 1], s=1.6, color=FRAUD, alpha=0.85, lw=0, rasterized=True)
            ax.axvline(0.755, color='k', ls='--', lw=0.7)
            ax.set_title(f'{SHORT[k]}  (AUC-ROC {safe_auc(yt, s):.2f})', fontsize=7.4, loc='left')
            ax.set_xlim(-0.02, 1.02); ax.set_ylim(-0.02, 1.02); ax.set_xticks([0, 0.25, 0.5, 0.75, 1.0]); ax.set_xticklabels(['0', '0.25', '0.5', '0.75', '1'])
            ax.set_yticks([0, 0.5, 1.0])
            if i == 1: ax.set_xlabel('Bot-likelihood score')
        axs[i, 0].set_ylabel(f'Regime {reg}\nAnomaly-score percentile')
    h = [Line2D([], [], ls='', marker='o', ms=3.4, color=NORMAL), Line2D([], [], ls='', marker='o', ms=3.4, color=FRAUD), Line2D([], [], color='k', ls='--', lw=0.7)]
    fig.legend(h, ['Normal click', 'Fraudulent click', 'Labelling threshold (0.75)'], loc='lower center', ncol=3, bbox_to_anchor=(0.55, 0.0), columnspacing=2.0)
    save(fig, 'Fig6_score_vs_bot')

# ------------------------------------------------------------------ Fig. 7 t-SNE by true label
if want('fig7'):
    st = pickle.load(open(os.path.join(OUTR, 'structure', 'structure.pkl'), 'rb')); sj = json.load(open(os.path.join(OUTR, 'structure', 'structure.json')))
    mix = {(m['space'], m['k']): m for m in sj['neighbourhood_mixing']}
    fig = plt.figure(figsize=(WIDTH, 72 * MM))
    gs = fig.add_gridspec(1, 4, width_ratios=[1, 1, 1, 0.05], left=0.01, right=0.915, top=0.91, bottom=0.25, wspace=0.07)
    axs = [fig.add_subplot(gs[0, i]) for i in range(3)]; cax = fig.add_subplot(gs[0, 3])
    for ax, name, letter, ttl in [(axs[0], 'FULL', 'a', 'All inputs'), (axs[1], 'NOBOT', 'b', 'Without bot score')]:
        E = st['tsne'][name]; yt = st['y_test']
        ax.scatter(E[yt == 0, 0], E[yt == 0, 1], s=2.2, color=NORMAL, alpha=0.8, lw=0, rasterized=True)
        ax.scatter(E[yt == 1, 0], E[yt == 1, 1], s=2.6, color=FRAUD, alpha=0.9, lw=0, rasterized=True)
        m = mix[(name, 10)]
        ptitle(ax, letter, ttl)
        ax.text(0.5, -0.035, f"Fraud share among the 10 nearest\nneighbours in the original space:\n{m['fraud_neighbour_share_fraud']:.2f} for fraudulent clicks,\n"
                             f"{m['fraud_neighbour_share_normal']:.2f} for normal (base rate {m['base_rate']:.2f})",
                transform=ax.transAxes, ha='center', va='top', fontsize=6.7, linespacing=1.22)
    E = st['tsne']['FULL']; c = st['consensus']['S']
    sc = axs[2].scatter(E[:, 0], E[:, 1], c=c, s=2.2, cmap='viridis', lw=0, rasterized=True)
    ptitle(axs[2], 'c', 'Consensus score, regime S')
    cb = fig.colorbar(sc, cax=cax); cb.set_label('Consensus score (mean percentile rank)', fontsize=7); cb.ax.tick_params(labelsize=6.8, width=0.5, length=2)
    cb.outline.set_linewidth(0.5)
    for ax in axs:
        ax.set_xticks([]); ax.set_yticks([]); ax.set_aspect('equal', adjustable='datalim')
        for sp in ax.spines.values(): sp.set_visible(True); sp.set_color('#BBBBBB'); sp.set_linewidth(0.5)
    h = [Line2D([], [], ls='', marker='o', ms=3.4, color=NORMAL), Line2D([], [], ls='', marker='o', ms=3.4, color=FRAUD)]
    axs[2].legend(h, ['Normal click', 'Fraudulent click'], loc='upper center', bbox_to_anchor=(0.5, -0.035), ncol=1, title='Point colours in (a) and (b)',
                  alignment='left', handletextpad=0.2, labelspacing=0.3)
    save(fig, 'Fig7_tsne_labels')

# ------------------------------------------------------------------ Fig. 8 threshold sensitivity
if want('fig8'):
    R = {(r['featureset'], r['regime'], r['model']): r for r in json.load(open(os.path.join(OUTR, 'main', 'main_results.json')))['rows']}
    qs = sorted(float(q) for q in R[('FULL', 'U', 'IF')]['q'])
    base = y[te].mean(); f_all = 2 * base / (1 + base)
    fig, axs = plt.subplots(1, 2, figsize=(WIDTH, 86 * MM), sharey=True)
    fig.subplots_adjust(left=0.075, right=0.99, top=0.92, bottom=0.27, wspace=0.07)
    for ax, reg, letter in zip(axs, ['U', 'S'], 'ab'):
        ax.axhline(f_all, **REF, zorder=1)
        for k in ORDER:
            r = R[('FULL', reg, k)]
            ax.plot([100 * r['q'][str(q)]['flag_rate'] for q in qs], [r['q'][str(q)]['f1'] for q in qs], color=COL[k], ls=LS[k], lw=1.0,
                    marker=MK[k], ms=2.6, mew=0, label=SHORT[k], zorder=3)
            ax.scatter([100 * r['cal']['flag_rate']], [r['cal']['f1']], color=COL[k], marker='*', s=46, edgecolor='k', lw=0.35, zorder=5)
        ax.set_xlabel('Share of test clicks flagged (%)'); ax.set_xlim(0, 101); ax.set_ylim(0, 0.78)
        ax.grid(True); ax.set_axisbelow(True)
        ptitle(ax, letter, REG[reg])
    axs[0].set_ylabel('Test F1-score')
    h, l = axs[0].get_legend_handles_labels()
    h += [Line2D([], [], color='#555555', marker='o', ms=2.6, mew=0, lw=1.0), Line2D([], [], ls='', marker='*', ms=7, mfc='white', mec='k', mew=0.6),
          Line2D([], [], **REF)]
    l += ['Flag rates q = 1–50% (fitting data)', 'Threshold from calibration split', f'Flag every click (F1 = {f_all:.3f})']
    fig.legend(h[:8], l[:8], loc='lower center', ncol=8, bbox_to_anchor=(0.53, 0.075), columnspacing=1.0, handlelength=2.0, handletextpad=0.35)
    fig.legend(h[8:], l[8:], loc='lower center', ncol=3, bbox_to_anchor=(0.53, 0.0), columnspacing=1.3, handlelength=2.0, handletextpad=0.35)
    save(fig, 'Fig8_threshold_sensitivity')

# ------------------------------------------------------------------ Fig. 9 DBSCAN grid
if want('fig9'):
    G = pd.DataFrame(json.load(open(os.path.join(OUTR, 'ablations', 'ablations.json')))['dbscan_grid'])
    rules = ['orig', 'p10', 'p25', 'p50', 'p75', 'p90', 'p95', 'p99', 'knee']; rl = ['0.5', 'P10', 'P25', 'P50', 'P75', 'P90', 'P95', 'P99', 'Knee']
    fig, axs = plt.subplots(2, 2, figsize=(WIDTH, 100 * MM), gridspec_kw={'width_ratios': [0.82, 1.0]})
    fig.subplots_adjust(left=0.065, right=0.995, top=0.94, bottom=0.1, wspace=0.1, hspace=0.52)
    from matplotlib.colors import LinearSegmentedColormap
    greys = LinearSegmentedColormap.from_list('g', ['#FFFFFF', '#5A5A5A'])
    for i, reg in enumerate(['U', 'S']):
        g = G[G.regime == reg]; mps = sorted(g.min_samples.unique())
        for j, (col, ttl) in enumerate([('test_auc_distance_score', 'test AUC-ROC'), ('n_clusters', 'clusters found (noise share)')]):
            ax = axs[i, j]
            M = np.array([[g[(g.min_samples == mp) & (g.eps_rule == r)][col].values[0] for r in rules] for mp in mps], float)
            if j == 0:
                vmin, vmax, cm = 0.3, 0.7, 'RdBu_r'
            else:
                vmin, vmax, cm = 0, max(4, M.max()), greys
            ax.imshow(M, aspect='auto', cmap=cm, vmin=vmin, vmax=vmax)
            for a in range(M.shape[0]):
                for b in range(M.shape[1]):
                    row = g[(g.min_samples == mps[a]) & (g.eps_rule == rules[b])].iloc[0]
                    txt = f"{M[a, b]:.2f}" if j == 0 else f"{int(M[a, b])}\n({100 * row['noise_fraction_train']:.0f}%)"
                    dark = abs(M[a, b] - 0.5) > 0.13 if j == 0 else M[a, b] > 0.55 * vmax
                    ax.text(b, a, txt, ha='center', va='center', fontsize=6.6 if j == 0 else 6.2, linespacing=1.1, color='white' if dark else '#111111')
            ax.set_xticks(range(len(rules))); ax.set_xticklabels(rl); ax.set_yticks(range(len(mps))); ax.set_yticklabels(mps)
            ax.tick_params(length=0)
            for sp in ax.spines.values(): sp.set_visible(False)
            ax.set_xticks(np.arange(-0.5, len(rules)), minor=True); ax.set_yticks(np.arange(-0.5, len(mps)), minor=True)
            ax.grid(which='minor', color='white', lw=0.8); ax.tick_params(which='minor', length=0)
            ax.set_xlabel('eps (0.5, k-distance percentile, or knee)', fontsize=7)
            if j == 0: ax.set_ylabel('minPts')
            ptitle(ax, chr(97 + 2 * i + j), f'Regime {reg}: {ttl}', fontsize=7.8)
    save(fig, 'Fig9_dbscan_grid')

# ------------------------------------------------------------------ Fig. 10 temporal stability and computational scaling
if want('fig10'):
    T = pd.DataFrame(json.load(open(os.path.join(OUTR, 'ablations', 'ablations.json')))['temporal']['rows'])
    tim = pd.DataFrame(json.load(open(os.path.join(OUTR, 'timing', 'timing.json')))['rows'])
    fig = plt.figure(figsize=(WIDTH, 70 * MM))
    gs = fig.add_gridspec(1, 4, width_ratios=[1, 1, 0.2, 1.0], left=0.07, right=0.99, top=0.91, bottom=0.31, wspace=0.08)
    ax0 = fig.add_subplot(gs[0, 0]); ax1 = fig.add_subplot(gs[0, 1], sharey=ax0); ax2 = fig.add_subplot(gs[0, 3])
    MON = {'01': 'Jan', '02': 'Feb', '03': 'Mar', '04': 'Apr', '05': 'May', '06': 'Jun', '07': 'Jul', '08': 'Aug', '09': 'Sep', '10': 'Oct', '11': 'Nov', '12': 'Dec'}
    for ax, reg, letter in zip([ax0, ax1], ['U', 'S'], 'ab'):
        ax.axhline(0.5, **REF, zorder=1)
        for k in ORDER:
            t = T[(T.regime == reg) & (T.model == k)].sort_values('month')
            ax.plot(range(len(t)), t['auc'], color=COL[k], ls=LS[k], marker=MK[k], ms=2.6, mew=0, lw=1.0, label=SHORT[k], zorder=3)
        months = T[(T.regime == reg) & (T.model == 'IF')].sort_values('month')['month'].tolist()
        ax.set_xticks(range(len(months)))
        ax.set_xticklabels([MON[m[5:]] + ('\n' + m[:4] if (i == 0 or m[5:] == '01') else '') for i, m in enumerate(months)], fontsize=6.6)
        ax.set_xlim(-0.4, len(months) - 0.6)
        ax.set_ylim(0.35, 1.0); ax.grid(axis='y'); ax.set_axisbelow(True)
        ax.set_xlabel('Test month')
        ptitle(ax, letter, REG[reg].replace(' training', ''), fontsize=7.8)
    ax0.set_ylabel('Monthly test AUC-ROC')
    plt.setp(ax1.get_yticklabels(), visible=False)
    for k in ORDER:
        t = tim[tim.model == k].sort_values('n_fit')
        ax2.plot(t['n_fit'], t['fit_seconds'], color=COL[k], ls=LS[k], marker=MK[k], ms=3, mew=0, lw=1.0, label=SHORT[k])
    ax2.set_xscale('log'); ax2.set_yscale('log'); ax2.set_xlabel('Training clicks'); ax2.set_ylabel('Fit time (s)')
    ax2.set_xticks([3e3, 1e4, 3e4, 1e5, 3e5]); ax2.set_xticklabels(['3k', '10k', '30k', '100k', '300k']); ax2.minorticks_off()
    ax2.grid(True, which='major'); ax2.set_axisbelow(True)
    ptitle(ax2, 'c', 'Fit time on two vCPUs', fontsize=7.8)
    h, l = ax0.get_legend_handles_labels()
    fig.legend(h, l, loc='lower center', ncol=8, bbox_to_anchor=(0.53, 0.0), columnspacing=1.1, handlelength=2.0, handletextpad=0.35)
    save(fig, 'Fig10_time_and_scale')
print('figures done')
