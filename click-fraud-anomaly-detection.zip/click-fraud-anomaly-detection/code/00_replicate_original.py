"""Step 0. Faithful re-run of the ORIGINAL notebook (topic8) on click_fraud_dataset.csv, followed by
diagnostics of the issues raised in review. Nothing here is used for the revised results; it documents
what the original pipeline did and which numbers in the submitted manuscript it produced.

Usage: python 00_replicate_original.py <data.csv> <out_dir>
"""
import json, os, sys, warnings
import numpy as np
import pandas as pd
from scipy import stats
warnings.filterwarnings('ignore')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
from sklearn.svm import OneClassSVM
from sklearn.cluster import DBSCAN
from sklearn.metrics import precision_recall_fscore_support, roc_auc_score, average_precision_score
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Input
from tensorflow.keras.optimizers import Adam

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
np.random.seed(42); tf.random.set_seed(42)
R = {}

# ---------------- CELL 2: data preparation (verbatim logic)
df = pd.read_csv(DATA, nrows=10000)
raw = df.copy()
R['raw_shape'] = list(df.shape); R['raw_fraud_rate'] = float(df['is_fraudulent'].mean())
df = df.drop_duplicates()
numeric_cols = ['click_duration', 'scroll_depth', 'mouse_movement', 'keystrokes_detected', 'bot_likelihood_score']
for col in numeric_cols:
    Q1, Q3 = df[col].quantile([0.25, 0.75]); IQR = Q3 - Q1
    df = df[(df[col] >= Q1 - 1.5 * IQR) & (df[col] <= Q3 + 1.5 * IQR)]
R['clean_shape'] = list(df.shape)
removed = raw.loc[~raw.index.isin(df.index)]
R['iqr_removed_n'] = int(len(removed)); R['iqr_removed_fraud_rate'] = float(removed['is_fraudulent'].mean())
R['clean_fraud_rate'] = float(df['is_fraudulent'].mean())
# which variable triggered removal (sequential filter -> attribute to first failing variable on the raw data)
trig = {}
tmp = raw.copy()
for col in numeric_cols:
    Q1, Q3 = tmp[col].quantile([0.25, 0.75]); IQR = Q3 - Q1
    bad = (tmp[col] < Q1 - 1.5 * IQR) | (tmp[col] > Q3 + 1.5 * IQR)
    trig[col] = {'n': int(bad.sum()), 'fraud_rate': float(tmp.loc[bad, 'is_fraudulent'].mean()) if bad.any() else None}
    tmp = tmp[~bad]
R['iqr_removed_by_variable'] = trig

# ---------------- CELL 3: feature engineering (verbatim logic)
df['timestamp'] = pd.to_datetime(df['timestamp'])
df = df.sort_values('timestamp').reset_index(drop=True)
R['date_range'] = [str(df['timestamp'].min()), str(df['timestamp'].max())]
df['hour_of_day'] = df['timestamp'].dt.hour
df['burstiness'] = df['click_frequency'].clip(0, 20)
df['time_since_log'] = np.log1p(df['time_since_last_click'].fillna(72))
df['user_session'] = (df['user_id'] != df['user_id'].shift()).cumsum()
df['clicks_per_session'] = df.groupby('user_session')['click_id'].transform('count')
df['session_behavior_score'] = df.groupby('user_session')['scroll_depth'].transform('mean')
ip_freq = df['ip_address'].value_counts(); df['ip_frequency'] = df['ip_address'].map(ip_freq)
browser_diversity = df.groupby('user_id')['browser'].transform(lambda x: x.nunique())
df['ua_entropy'] = browser_diversity / df.groupby('user_id')['browser'].transform('count')
df['ua_entropy'] = df['ua_entropy'].fillna(0) * np.log(5)
df['rare_combo'] = 0
combo_counts = df['ad_position'].astype(str) + '_' + df['referrer_url'].fillna('none').str[:8]
rare_mask = combo_counts.isin(combo_counts.value_counts()[combo_counts.value_counts() < 5].index)
df.loc[rare_mask, 'rare_combo'] = 1
for col in ['bot_likelihood_score', 'click_duration']:
    df[f'{col}_z'] = stats.zscore(df[col].fillna(df[col].median()))
for grp in ['user_id', 'ip_address']:
    df[f'clicks_per_{grp}'] = df.groupby(grp)['click_id'].transform('count')
    df[f'vpn_per_{grp}'] = df.groupby(grp)['VPN_usage'].transform('mean')
R['n_columns_after_fe'] = int(df.shape[1])

# ---------------- CELL 4: scaling (verbatim)
le = LabelEncoder(); df['device_ip_reputation_encoded'] = le.fit_transform(df['device_ip_reputation'].astype(str))
R['ip_reputation_encoding'] = {c: int(i) for i, c in enumerate(le.classes_)}
feature_cols = ['bot_likelihood_score_z', 'click_duration_z', 'ip_frequency', 'ua_entropy', 'rare_combo', 'burstiness', 'hour_of_day',
                'clicks_per_user_id', 'clicks_per_ip_address', 'vpn_per_user_id', 'time_since_log', 'scroll_depth', 'mouse_movement',
                'keystrokes_detected', 'click_frequency', 'device_ip_reputation_encoded', 'VPN_usage', 'proxy_usage']
X = df[feature_cols].fillna(0)
X_scaled = pd.DataFrame(StandardScaler().fit_transform(X), columns=feature_cols, index=df.index)

# feature diagnostics: constants and exact duplicates among the 18 inputs
const = [c for c in feature_cols if X[c].nunique() == 1]
dups = []
for i, a in enumerate(feature_cols):
    for b in feature_cols[i + 1:]:
        if np.allclose(X_scaled[a].values, X_scaled[b].values):
            dups.append([a, b])
R['constant_inputs'] = const; R['duplicate_inputs'] = dups
R['rare_combo_n'] = int(df['rare_combo'].sum())
R['all_engineered_constant'] = [c for c in df.columns if df[c].nunique() == 1]

# ---------------- CELL 5/6: models (verbatim)
res = pd.DataFrame(index=df.index)
iso = IsolationForest(contamination=0.1, n_estimators=100, random_state=42)
res['IF_label'] = iso.fit_predict(X_scaled); res['IF_score'] = iso.decision_function(X_scaled)
lof = LocalOutlierFactor(n_neighbors=20, contamination=0.1)
res['LOF_label'] = lof.fit_predict(X_scaled); res['LOF_score'] = -lof.negative_outlier_factor_
oc = OneClassSVM(nu=0.1, kernel='rbf')
res['OCSVM_label'] = oc.fit_predict(X_scaled); res['OCSVM_score'] = oc.decision_function(X_scaled)
db = DBSCAN(eps=0.5, min_samples=5); dbl = db.fit_predict(X_scaled)
R['dbscan'] = {'n_clusters': int(len(set(dbl[dbl > -1]))), 'noise_fraction': float((dbl == -1).mean())}
X_normal = X_scaled[df['is_fraudulent'] == 0]
R['ae_train_n'] = int(len(X_normal))
model = Sequential([Input(shape=(X.shape[1],)), Dense(32, activation='relu'), Dense(16, activation='relu'), Dense(8, activation='relu'),
                    Dense(16, activation='relu'), Dense(32, activation='relu'), Dense(X.shape[1], activation='linear')])
model.compile(optimizer=Adam(0.001), loss='mse')
model.fit(X_normal, X_normal, epochs=30, batch_size=64, verbose=0)
recon = model.predict(X_scaled, verbose=0)
mse = np.mean(np.power(X_scaled - recon, 2), axis=1)
res['AE_label'] = (mse > np.percentile(mse, 90)).astype(int); res['AE_score'] = mse

# ---------------- CELL 7: evaluation (verbatim, including the label convention used for all four models)
y = df['is_fraudulent'].values
orig = {}
for p in ['IF', 'LOF', 'OCSVM', 'AE']:
    yp = (res[f'{p}_label'] == -1).astype(int)
    pr, rc, f1, _ = precision_recall_fscore_support(y, yp, average='binary', zero_division=0)
    orig[p] = {'precision': pr, 'recall': rc, 'f1': f1, 'auc': roc_auc_score(y, res[f'{p}_score'])}
R['original_metrics_as_coded'] = orig

# ---------------- Diagnostics
diag = {}
# (a) score orientation: sklearn decision_function is HIGHER for MORE NORMAL points (IF, OCSVM)
diag['auc_oriented'] = {'IF': roc_auc_score(y, -res['IF_score']), 'LOF': roc_auc_score(y, res['LOF_score']),
                        'OCSVM': roc_auc_score(y, -res['OCSVM_score']), 'AE': roc_auc_score(y, res['AE_score'])}
diag['ap_oriented'] = {'IF': average_precision_score(y, -res['IF_score']), 'LOF': average_precision_score(y, res['LOF_score']),
                       'OCSVM': average_precision_score(y, -res['OCSVM_score']), 'AE': average_precision_score(y, res['AE_score'])}
# (b) AE label convention: AE_label is 0/1, the evaluation loop tests == -1, so no click is ever predicted fraudulent
ypa = res['AE_label'].values
pr, rc, f1, _ = precision_recall_fscore_support(y, ypa, average='binary', zero_division=0)
diag['ae_fixed_label_at_p90'] = {'precision': pr, 'recall': rc, 'f1': f1, 'n_flagged': int(ypa.sum())}
diag['ae_predicted_positive_as_coded'] = int((res['AE_label'] == -1).sum())
# AE AUC separately on the normal clicks that were used for training vs fraud (in-sample issue)
diag['ae_auc_note'] = 'all 3,556 normal clicks scored by the AE were also its training data'
# (c) composition of avg_score used for top-20 and t-SNE colouring (mixes normality and anomaly scores on different scales)
sc = res[['IF_score', 'LOF_score', 'OCSVM_score', 'AE_score']]
diag['score_scale'] = {c: {'min': float(sc[c].min()), 'median': float(sc[c].median()), 'max': float(sc[c].max()), 'sd': float(sc[c].std())} for c in sc}
avg = sc.mean(1)
diag['corr_avg_with_each'] = {c: float(np.corrcoef(avg, sc[c])[0, 1]) for c in sc}
diag['auc_avg_score'] = roc_auc_score(y, avg)
top = avg.nlargest(20).index
diag['top20_fraud_count'] = int(y[top].sum())
diag['top20_vpn_proxy'] = [int(df.loc[top, 'VPN_usage'].sum()), int(df.loc[top, 'proxy_usage'].sum())]
diag['top20_bot_mean_sd'] = [float(df.loc[top, 'bot_likelihood_score'].mean()), float(df.loc[top, 'bot_likelihood_score'].std())]
diag['population_bot_mean_sd'] = [float(df['bot_likelihood_score'].mean()), float(df['bot_likelihood_score'].std())]
diag['top20_ip_frequency_values'] = sorted(set(df.loc[top, 'ip_frequency'].tolist()))
diag['population_ip_frequency_values'] = sorted(set(df['ip_frequency'].tolist()))
# (d) clicks with 0 VPN and 0 proxy in the population
diag['population_share_vpn0_proxy0'] = float(((df['VPN_usage'] == 0) & (df['proxy_usage'] == 0)).mean())
R['diagnostics'] = diag
res.assign(is_fraudulent=y).to_csv(os.path.join(OUT, 'original_pipeline_scores.csv'), index=False)
json.dump(R, open(os.path.join(OUT, 'replication_original.json'), 'w'), indent=1, default=float)
print(json.dumps(R, indent=1, default=lambda o: round(float(o), 4)))
