"""Step 5. Computational scaling (not detection performance): fit time and scoring throughput as the number of
training clicks grows. Larger training sets are formed by resampling the standardised FULL-feature training rows with
replacement and adding small Gaussian jitter (SD 0.01) to avoid exact duplicates. Each detector is warmed up once
(untimed); fitting is then timed 5 times (if one fit takes < 2 s), 3 times (< 20 s) or once, scoring of 100,000 clicks
is timed by the same rule, and medians are reported. Run on its own, with no other jobs.

Usage: python 05_timing.py <data.csv> <out_dir>
"""
import json, os, sys, time, platform
import numpy as np, pandas as pd
from cf_lib import *

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
df = load(DATA); y = df['is_fraudulent'].values.astype(int)
tr, ca, te = chrono_split(len(df))
P = Prep(FEATURES['FULL']).fit(df.iloc[tr]); Xtr = P.transform(df.iloc[tr])
rng = np.random.default_rng(0)
def replica(n):
    return (Xtr[rng.integers(0, len(Xtr), n)] + rng.normal(0, 0.01, (n, Xtr.shape[1]))).astype(np.float32)
Xscore = replica(100_000)
LIMITS = {'IF': 300_000, 'ECOD': 300_000, 'AE': 300_000, 'DSVDD': 300_000, 'LOF': 30_000, 'OCSVM': 30_000, 'DBSCAN': 30_000, 'TRF': 30_000}
def n_reps(first):
    """Number of timed repetitions given the duration of the first one: 5 below 2 s, 3 below 20 s, otherwise 1."""
    return 5 if first < 2 else (3 if first < 20 else 1)

# One untimed warm-up fit and score per detector, so that library loading, thread-pool start-up and graph tracing
# are not charged to the first measured configuration.
for k in ORDER:
    w = MODELS[k](0); w.fit(Xtr[:500]); w.score(Xtr[:200])
rows = []
for n in [3_000, 30_000, 300_000]:
    Xfit = replica(n) if n != 3_000 else Xtr
    for k in ORDER:
        if n > LIMITS[k]:
            continue
        fits, scores = [], []
        while True:
            m = MODELS[k](0)
            t0 = time.perf_counter(); m.fit(Xfit); fits.append(time.perf_counter() - t0)
            t0 = time.perf_counter(); m.score(Xscore); scores.append(time.perf_counter() - t0)
            if len(fits) >= n_reps(fits[0]):
                break
        while len(scores) < n_reps(scores[0]):          # scoring is repeated on the last fitted model when it is cheap
            t0 = time.perf_counter(); m.score(Xscore); scores.append(time.perf_counter() - t0)
        tf_, ts = float(np.median(fits)), float(np.median(scores))
        rows.append({'model': k, 'n_fit': n, 'repetitions': len(fits), 'fit_seconds': tf_, 'score_seconds_100k': ts,
                     'clicks_per_second': 100_000 / ts, 'microseconds_per_click': ts / 100_000 * 1e6,
                     'fit_seconds_min': min(fits), 'fit_seconds_max': max(fits), 'score_repetitions': len(scores)})
        print(rows[-1], flush=True)
        pd.DataFrame(rows).to_csv(os.path.join(OUT, 'timing.csv'), index=False)
cpu = ''
try:
    cpu = [l.split(':')[1].strip() for l in open('/proc/cpuinfo') if l.startswith('model name')][0]
except Exception:
    pass
json.dump({'hardware': {'cpu': cpu, 'logical_cores': os.cpu_count(), 'platform': platform.platform(), 'python': platform.python_version()},
           'rows': rows, 'limits': LIMITS}, open(os.path.join(OUT, 'timing.json'), 'w'), indent=1, default=float)
print('done')
