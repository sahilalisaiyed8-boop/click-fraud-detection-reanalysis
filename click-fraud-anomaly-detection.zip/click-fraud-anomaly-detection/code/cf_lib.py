"""Shared library for the revised click-fraud anomaly-detection benchmark (MEADIG-D-26-00099, revision 1).

Conventions
- Every detector returns an anomaly score oriented so that HIGHER = MORE ANOMALOUS.
- Preprocessing (scaling, rare-combination counts, IQR limits) is fitted on the training split only.
- Two information regimes: 'U' = fully unsupervised, fitted on the contaminated training split without labels;
  'S' = clean-normal (one-class / semi-supervised), fitted on the label-selected normal clicks of the training split.
"""
import os, random, time, warnings
import numpy as np
import pandas as pd
warnings.filterwarnings('ignore')
os.environ.setdefault('TF_CPP_MIN_LOG_LEVEL', '3')
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor, NearestNeighbors
from sklearn.svm import OneClassSVM
from sklearn.cluster import DBSCAN
from sklearn.metrics import roc_auc_score, average_precision_score, precision_recall_fscore_support, precision_recall_curve

REP_ORD = {'Good': 0, 'Suspicious': 1, 'Bad': 2}

# ----------------------------------------------------------------------------------------------- data
def load(path):
    df = pd.read_csv(path)
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values('timestamp', kind='mergesort').reset_index(drop=True)
    df['hour_of_day'] = df['timestamp'].dt.hour
    df['time_since_log'] = np.log1p(df['time_since_last_click'])
    df['ip_reputation_ord'] = df['device_ip_reputation'].map(REP_ORD).astype(float)
    df['combo'] = df['ad_position'].astype(str) + '_' + df['referrer_url'].fillna('none').str[:8]
    # past-only identity features (time-ordered, expanding counts; no future information)
    df['ip_prior_clicks'] = df.groupby('ip_address').cumcount()
    df['user_prior_clicks'] = df.groupby('user_id').cumcount()
    return df


FEATURES = {
    # cleaned version of the submitted 18 inputs: constants and exact duplicates removed, ordinal reputation code,
    # rare_combo from training counts, plus the two past-only identity counts (constant here and dropped automatically)
    'FULL': ['bot_likelihood_score', 'click_duration', 'scroll_depth', 'mouse_movement', 'keystrokes_detected', 'click_frequency',
             'time_since_log', 'hour_of_day', 'ip_reputation_ord', 'VPN_usage', 'proxy_usage', 'rare_combo',
             'ip_prior_clicks', 'user_prior_clicks'],
    'NOBOT': ['click_duration', 'scroll_depth', 'mouse_movement', 'keystrokes_detected', 'click_frequency',
              'time_since_log', 'hour_of_day', 'ip_reputation_ord', 'VPN_usage', 'proxy_usage', 'rare_combo',
              'ip_prior_clicks', 'user_prior_clicks'],
    'BEHAV': ['click_duration', 'scroll_depth', 'mouse_movement', 'keystrokes_detected', 'click_frequency', 'time_since_log',
              'hour_of_day'],
}
ORIG18 = ['bot_likelihood_score_z', 'click_duration_z', 'ip_frequency', 'ua_entropy', 'rare_combo', 'burstiness', 'hour_of_day',
          'clicks_per_user_id', 'clicks_per_ip_address', 'vpn_per_user_id', 'time_since_log', 'scroll_depth', 'mouse_movement',
          'keystrokes_detected', 'click_frequency', 'device_ip_reputation_encoded', 'VPN_usage', 'proxy_usage']


def add_orig18(df):
    """The 18 inputs of the submitted notebook, with the same (full-sample) definitions, for the correction ladder only."""
    d = df.copy()
    d['burstiness'] = d['click_frequency'].clip(0, 20)
    d['ip_frequency'] = d['ip_address'].map(d['ip_address'].value_counts())
    bd = d.groupby('user_id')['browser'].transform(lambda x: x.nunique())
    d['ua_entropy'] = (bd / d.groupby('user_id')['browser'].transform('count')).fillna(0) * np.log(5)
    for c in ['bot_likelihood_score', 'click_duration']:
        d[f'{c}_z'] = (d[c] - d[c].mean()) / d[c].std(ddof=0)
    for g in ['user_id', 'ip_address']:
        d[f'clicks_per_{g}'] = d.groupby(g)['click_id'].transform('count')
        d[f'vpn_per_{g}'] = d.groupby(g)['VPN_usage'].transform('mean')
    d['device_ip_reputation_encoded'] = d['device_ip_reputation'].map({'Bad': 0, 'Good': 1, 'Suspicious': 2})
    cc = d['combo'].value_counts()
    d['rare_combo_full'] = d['combo'].map(cc).lt(5).astype(int)
    return d


def iqr_limits(train, cols=('click_duration', 'scroll_depth', 'mouse_movement', 'keystrokes_detected', 'bot_likelihood_score')):
    lim = {}
    for c in cols:
        q1, q3 = train[c].quantile([0.25, 0.75]); i = q3 - q1
        lim[c] = (q1 - 1.5 * i, q3 + 1.5 * i)
    return lim


def iqr_mask(d, lim):
    m = np.ones(len(d), bool)
    for c, (lo, hi) in lim.items():
        m &= (d[c] >= lo).values & (d[c] <= hi).values
    return m


class Prep:
    """Feature builder fitted on the training split only."""
    def __init__(self, feats, orig18=False):
        self.feats, self.orig18 = list(feats), orig18

    def fit(self, train):
        tr = train.copy()
        if not self.orig18:
            self.combo_counts = tr['combo'].value_counts()
            tr['rare_combo'] = self._rare(tr)
        X = tr[self.feats].astype(float)
        # drop columns that are constant in the training split (e.g., the past-only IP/user counts in this dataset)
        self.keep = [c for c in self.feats if X[c].nunique() > 1] if not self.orig18 else list(self.feats)
        self.dropped = [c for c in self.feats if c not in self.keep]
        self.scaler = StandardScaler().fit(X[self.keep])
        return self

    def _rare(self, d):
        return d['combo'].map(self.combo_counts).fillna(0).lt(5).astype(int)

    def transform(self, d):
        d = d.copy()
        if not self.orig18:
            d['rare_combo'] = self._rare(d)
        return self.scaler.transform(d[self.keep].astype(float)).astype(np.float32)


# ----------------------------------------------------------------------------------------------- splits
def chrono_split(n, fr=(0.6, 0.2, 0.2)):
    a, b = int(round(n * fr[0])), int(round(n * (fr[0] + fr[1])))
    idx = np.arange(n)
    return idx[:a], idx[a:b], idx[b:]


def strat_split(y, seed, fr=(0.6, 0.2, 0.2)):
    rng = np.random.default_rng(seed)
    tr, ca, te = [], [], []
    for cls in np.unique(y):
        ii = np.where(y == cls)[0]; rng.shuffle(ii)
        a, b = int(round(len(ii) * fr[0])), int(round(len(ii) * (fr[0] + fr[1])))
        tr += list(ii[:a]); ca += list(ii[a:b]); te += list(ii[b:])
    return np.sort(tr), np.sort(ca), np.sort(te)


# ----------------------------------------------------------------------------------------------- seeds / TF
def set_seed(seed):
    random.seed(seed); np.random.seed(seed)
    import tensorflow as tf
    tf.random.set_seed(seed)
    try:
        tf.keras.utils.set_random_seed(seed)
    except Exception:
        pass


def _tf():
    import tensorflow as tf
    return tf


# ----------------------------------------------------------------------------------------------- detectors
class IF_:
    name = 'Isolation Forest'
    def __init__(self, seed, n_estimators=100, max_samples='auto'):
        self.m = IsolationForest(n_estimators=n_estimators, max_samples=max_samples, random_state=seed)
    def fit(self, X): self.m.fit(X); return self
    def score(self, X): return -self.m.score_samples(X)


class LOF_:
    name = 'Local Outlier Factor'
    def __init__(self, seed, k=20):
        self.m = LocalOutlierFactor(n_neighbors=k, novelty=True)
    def fit(self, X): self.m.fit(X); return self
    def score(self, X): return -self.m.score_samples(X)


class OCSVM_:
    name = 'One-Class SVM'
    def __init__(self, seed, nu=0.1, gamma='scale'):
        self.m = OneClassSVM(nu=nu, kernel='rbf', gamma=gamma)
    def fit(self, X): self.m.fit(X); return self
    def score(self, X): return -self.m.decision_function(X)


class DBSCAN_:
    """DBSCAN fitted on training data. Continuous score = Euclidean distance to the nearest core sample;
    a point is noise (anomalous) when that distance exceeds eps. Default: minPts = 2*dim and eps at the knee of the
    sorted k-distance curve (Ester et al., 1996; Schubert et al., 2017)."""
    name = 'DBSCAN'
    def __init__(self, seed, eps=None, min_samples=None):
        self.eps, self.min_samples = eps, min_samples

    @staticmethod
    def knee_eps(X, k):
        d = NearestNeighbors(n_neighbors=k).fit(X).kneighbors(X)[0][:, -1]
        s = np.sort(d); x = np.linspace(0, 1, len(s)); yv = (s - s[0]) / (s[-1] - s[0] + 1e-12)
        return float(s[np.argmax(x - yv)])  # maximum distance below the chord of the convex k-distance curve

    def fit(self, X):
        if self.min_samples is None: self.min_samples = 2 * X.shape[1]
        if self.eps is None: self.eps = self.knee_eps(X, self.min_samples)
        self.m = DBSCAN(eps=self.eps, min_samples=self.min_samples).fit(X)
        lab = self.m.labels_
        self.n_clusters = int(len(set(lab[lab >= 0]))); self.noise_fraction = float((lab == -1).mean())
        core = X[self.m.core_sample_indices_] if len(self.m.core_sample_indices_) else X[:1] * np.inf
        self.nn = NearestNeighbors(n_neighbors=1).fit(core) if np.isfinite(core).all() else None
        self.train_labels = lab
        return self

    def score(self, X):
        if self.nn is None: return np.full(len(X), np.inf)
        return self.nn.kneighbors(X)[0][:, 0]


class ECOD_:
    name = 'ECOD'
    def __init__(self, seed):
        from pyod.models.ecod import ECOD
        self.m = ECOD()
    def fit(self, X): self.m.fit(X); return self
    def score(self, X): return self.m.decision_function(X)


class AE_:
    """Same architecture and training settings as the submitted study: d-32-16-8-16-32-d, ReLU, linear output,
    Adam (lr 0.001), MSE loss, batch 64, 30 epochs. Score = per-click mean squared reconstruction error."""
    name = 'Autoencoder'
    def __init__(self, seed, epochs=30):
        self.seed, self.epochs = seed, epochs
    def fit(self, X):
        tf = _tf(); set_seed(self.seed); d = X.shape[1]
        L = tf.keras.layers
        self.m = tf.keras.Sequential([L.Input((d,)), L.Dense(32, activation='relu'), L.Dense(16, activation='relu'), L.Dense(8, activation='relu'),
                                      L.Dense(16, activation='relu'), L.Dense(32, activation='relu'), L.Dense(d, activation='linear')])
        self.m.compile(optimizer=tf.keras.optimizers.Adam(0.001), loss='mse')
        self.m.fit(X, X, epochs=self.epochs, batch_size=64, verbose=0, shuffle=True)
        return self
    def score(self, X):
        r = self.m.predict(X, verbose=0, batch_size=2048)
        return np.mean((X - r) ** 2, axis=1)


class DSVDD_:
    """Deep SVDD (Ruff et al., 2018), one-class objective. Bias-free encoder d-32-16-8 with LeakyReLU, weight decay 1e-6,
    hypersphere centre fixed from an initial forward pass; Adam (lr 0.001), batch 64, 30 epochs. Score = squared distance to centre."""
    name = 'Deep SVDD'
    def __init__(self, seed, epochs=30):
        self.seed, self.epochs = seed, epochs
    def fit(self, X):
        tf = _tf(); set_seed(self.seed); L = tf.keras.layers; reg = tf.keras.regularizers.l2(1e-6); d = X.shape[1]
        self.enc = tf.keras.Sequential([L.Input((d,)), L.Dense(32, use_bias=False, kernel_regularizer=reg), L.LeakyReLU(0.1),
                                        L.Dense(16, use_bias=False, kernel_regularizer=reg), L.LeakyReLU(0.1),
                                        L.Dense(8, use_bias=False, kernel_regularizer=reg)])
        c = self.enc.predict(X, verbose=0, batch_size=2048).mean(0)
        c[(np.abs(c) < 0.1) & (c < 0)] = -0.1; c[(np.abs(c) < 0.1) & (c >= 0)] = 0.1
        self.c = tf.constant(c, dtype=tf.float32)
        opt = tf.keras.optimizers.Adam(0.001)
        ds = tf.data.Dataset.from_tensor_slices(X).shuffle(len(X), seed=self.seed, reshuffle_each_iteration=True).batch(64)
        enc, cc = self.enc, self.c

        @tf.function
        def step(xb):
            with tf.GradientTape() as tape:
                z = enc(xb, training=True)
                loss = tf.reduce_mean(tf.reduce_sum(tf.square(z - cc), axis=1)) + tf.add_n(enc.losses)
            g = tape.gradient(loss, enc.trainable_variables); opt.apply_gradients(zip(g, enc.trainable_variables))
            return loss
        for _ in range(self.epochs):
            for xb in ds:
                step(xb)
        return self
    def score(self, X):
        z = self.enc.predict(X, verbose=0, batch_size=2048)
        return np.sum((z - self.c.numpy()) ** 2, axis=1)


class TRF_:
    """Transformer detector with masked-feature reconstruction. Each feature is a token (FT-Transformer-style linear
    tokenizer, Gorishniy et al., 2021); two pre-norm encoder blocks (4 heads, width 32, feed-forward 64, GELU); training
    masks 25% of the feature tokens per click and reconstructs them (masked cell modelling; Yin et al., 2024).
    Score = mean squared error of reconstructing each feature when it alone is masked. Adam (lr 0.001), batch 64, 30 epochs."""
    name = 'Transformer'
    def __init__(self, seed, epochs=30, dim=32, heads=4, blocks=2, mask_rate=0.25):
        self.seed, self.epochs, self.D, self.h, self.nb, self.mr = seed, epochs, dim, heads, blocks, mask_rate

    def _build(self, d):
        tf = _tf(); L = tf.keras.layers; D = self.D
        x_in = L.Input((d,)); m_in = L.Input((d,))

        class Tok(L.Layer):
            def build(self_, shp):
                self_.W = self_.add_weight(name='W', shape=(d, D), initializer='glorot_uniform')
                self_.B = self_.add_weight(name='B', shape=(d, D), initializer='zeros')
                self_.M = self_.add_weight(name='M', shape=(1, 1, D), initializer='glorot_uniform')
            def call(self_, inputs):
                x, m = inputs
                t = x[:, :, None] * self_.W[None] + self_.B[None]
                mm = m[:, :, None]
                return t * (1.0 - mm) + (self_.M + self_.B[None]) * mm

        t = Tok()([x_in, m_in])
        for _ in range(self.nb):
            a = L.LayerNormalization()(t)
            a = L.MultiHeadAttention(num_heads=self.h, key_dim=D // self.h)(a, a)
            t = L.Add()([t, a])
            f = L.LayerNormalization()(t)
            f = L.Dense(2 * D, activation='gelu')(f); f = L.Dense(D)(f)
            t = L.Add()([t, f])
        t = L.LayerNormalization()(t)
        out = L.Reshape((d,))(L.Dense(1)(t))
        return tf.keras.Model([x_in, m_in], out)

    def fit(self, X):
        tf = _tf(); set_seed(self.seed); d = X.shape[1]
        self.m = self._build(d); opt = tf.keras.optimizers.Adam(0.001); model = self.m; mr = self.mr

        @tf.function
        def step(xb):
            n = tf.shape(xb)[0]
            m = tf.cast(tf.random.uniform((n, d)) < mr, tf.float32)
            # guarantee at least one masked token per click
            one = tf.one_hot(tf.random.uniform((n,), 0, d, dtype=tf.int32), d)
            m = tf.maximum(m, one * tf.cast(tf.reduce_sum(m, 1, keepdims=True) == 0, tf.float32))
            with tf.GradientTape() as tape:
                p = model([xb, m], training=True)
                loss = tf.reduce_sum(tf.square(p - xb) * m) / tf.reduce_sum(m)
            g = tape.gradient(loss, model.trainable_variables); opt.apply_gradients(zip(g, model.trainable_variables))
            return loss
        ds = tf.data.Dataset.from_tensor_slices(X).shuffle(len(X), seed=self.seed, reshuffle_each_iteration=True).batch(64)
        for _ in range(self.epochs):
            for xb in ds:
                step(xb)
        return self

    def score(self, X):
        n, d = X.shape; err = np.zeros(n)
        for j in range(d):
            m = np.zeros((n, d), np.float32); m[:, j] = 1.0
            p = self.m.predict([X, m], verbose=0, batch_size=2048)
            err += (p[:, j] - X[:, j]) ** 2
        return err / d


MODELS = {'IF': IF_, 'LOF': LOF_, 'OCSVM': OCSVM_, 'DBSCAN': DBSCAN_, 'AE': AE_, 'ECOD': ECOD_, 'DSVDD': DSVDD_, 'TRF': TRF_}
MODEL_NAMES = {k: v.name for k, v in MODELS.items()}
ORDER = ['IF', 'LOF', 'OCSVM', 'DBSCAN', 'AE', 'ECOD', 'DSVDD', 'TRF']


# ----------------------------------------------------------------------------------------------- metrics
def safe_auc(y, s):
    s = np.asarray(s, float)
    if not np.isfinite(s).all():
        s = np.where(np.isfinite(s), s, np.nanmax(s[np.isfinite(s)]) + 1 if np.isfinite(s).any() else 0)
    if np.unique(s).size == 1: return 0.5
    return roc_auc_score(y, s)


def safe_ap(y, s):
    s = np.asarray(s, float)
    if not np.isfinite(s).all():
        s = np.where(np.isfinite(s), s, np.nanmax(s[np.isfinite(s)]) + 1 if np.isfinite(s).any() else 0)
    if np.unique(s).size == 1: return float(np.mean(y))
    return average_precision_score(y, s)


def prf(y, flag):
    p, r, f, _ = precision_recall_fscore_support(y, flag.astype(int), average='binary', zero_division=0)
    return float(p), float(r), float(f)


def best_f1_threshold(y, s):
    """Threshold maximising F1 on a labelled calibration set."""
    p, r, t = precision_recall_curve(y, s)
    f = np.where(p + r > 0, 2 * p * r / (p + r + 1e-12), 0)[:-1]
    if len(t) == 0: return np.inf
    return float(t[np.argmax(f)])


def precision_at_k(y, s, k):
    o = np.argsort(-np.asarray(s), kind='mergesort')[:k]
    return float(np.mean(np.asarray(y)[o]))


def fast_auc(y, s):
    """Mann-Whitney AUC with average ranks for ties (identical to sklearn's roc_auc_score)."""
    from scipy.stats import rankdata
    y = np.asarray(y); s = np.asarray(s, float)
    npos = y.sum(); nneg = len(y) - npos
    if npos == 0 or nneg == 0: return np.nan
    r = rankdata(s)
    return float((r[y == 1].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def fast_ap(y, s):
    """Average precision with sklearn's step-wise definition (ties grouped at distinct thresholds)."""
    y = np.asarray(y); s = np.asarray(s, float)
    o = np.argsort(-s, kind='mergesort'); ys = y[o]; ss = s[o]
    distinct = np.where(np.diff(ss))[0]; idx = np.r_[distinct, len(ys) - 1]
    tps = np.cumsum(ys)[idx]; fps = (idx + 1) - tps
    if tps[-1] == 0: return np.nan
    prec = tps / (tps + fps); rec = tps / tps[-1]
    return float(np.sum(np.diff(np.r_[0, rec]) * prec))


def fast_f1(y, flag):
    y = np.asarray(y); f = np.asarray(flag) > 0.5
    tp = np.sum(f & (y == 1)); fp = np.sum(f & (y == 0)); fn = np.sum(~f & (y == 1))
    return float(2 * tp / (2 * tp + fp + fn)) if (2 * tp + fp + fn) > 0 else 0.0


def _clean(s):
    s = np.asarray(s, float)
    if not np.isfinite(s).all():
        fin = s[np.isfinite(s)]
        s = np.where(np.isfinite(s), s, (fin.max() + 1) if fin.size else 0.0)
    return s


def bootstrap_ci(y, s, fn, B=2000, seed=0, alpha=0.05):
    rng = np.random.default_rng(seed); n = len(y); vals = []
    y = np.asarray(y); s = _clean(s)
    for _ in range(B):
        i = rng.integers(0, n, n)
        if y[i].min() == y[i].max(): continue
        vals.append(fn(y[i], s[i]))
    return float(np.percentile(vals, 100 * alpha / 2)), float(np.percentile(vals, 100 * (1 - alpha / 2)))


def paired_bootstrap_diff(y, s1, s2, fn, B=2000, seed=0):
    rng = np.random.default_rng(seed); n = len(y); d = []
    y = np.asarray(y); s1 = _clean(s1); s2 = _clean(s2)
    for _ in range(B):
        i = rng.integers(0, n, n)
        if y[i].min() == y[i].max(): continue
        d.append(fn(y[i], s1[i]) - fn(y[i], s2[i]))
    d = np.array(d)
    return float(np.mean(d)), float(np.percentile(d, 2.5)), float(np.percentile(d, 97.5)), float(min(1.0, 2 * min((d <= 0).mean(), (d >= 0).mean())))


def timed(f, *a):
    t0 = time.perf_counter(); r = f(*a); return r, time.perf_counter() - t0
