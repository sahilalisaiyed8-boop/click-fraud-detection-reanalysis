"""Step 2. Run-to-run variability: R = 10 stratified random 60/20/20 splits, each with its own model seed.
Feature sets FULL and NOBOT, regimes U and S, all eight detectors. Reports mean, SD and the 2.5/97.5 percentiles over
repetitions of test AUC-ROC, average precision and F1 at the calibration-selected threshold.

Usage: python 02_repeats.py <data.csv> <out_dir> [R]
"""
import json, os, sys
import numpy as np, pandas as pd
from cf_lib import *

DATA, OUT = sys.argv[1], sys.argv[2]
R = int(sys.argv[3]) if len(sys.argv) > 3 else 10
os.makedirs(OUT, exist_ok=True)
df = load(DATA); y = df['is_fraudulent'].values.astype(int)
rows = []
for rep in range(R):
    tr, ca, te = strat_split(y, seed=1000 + rep)
    for fs in ['FULL', 'NOBOT']:
        P = Prep(FEATURES[fs]).fit(df.iloc[tr])
        Xtr, Xca, Xte = P.transform(df.iloc[tr]), P.transform(df.iloc[ca]), P.transform(df.iloc[te])
        for regime in ['U', 'S']:
            Xfit = Xtr if regime == 'U' else Xtr[y[tr] == 0]
            for k in ORDER:
                m = MODELS[k](rep).fit(Xfit)
                st, sc = m.score(Xte), m.score(Xca)
                t = best_f1_threshold(y[ca], sc)
                p, r, f = prf(y[te], st >= t)
                t10 = np.quantile(m.score(Xfit), 0.9); p10, r10, f10 = prf(y[te], st > t10)
                rows.append({'rep': rep, 'featureset': fs, 'regime': regime, 'model': k, 'auc': safe_auc(y[te], st), 'ap': safe_ap(y[te], st),
                             'f1_cal': f, 'prec_cal': p, 'rec_cal': r, 'f1_q10': f10, 'test_fraud_rate': float(y[te].mean())})
                print(rep, fs, regime, k, round(rows[-1]['auc'], 3), round(rows[-1]['ap'], 3), round(f, 3), flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(OUT, 'repeats_long.csv'), index=False)

d = pd.DataFrame(rows)
g = d.groupby(['featureset', 'regime', 'model'])
summ = g.agg(auc_mean=('auc', 'mean'), auc_sd=('auc', 'std'), auc_p025=('auc', lambda v: np.percentile(v, 2.5)), auc_p975=('auc', lambda v: np.percentile(v, 97.5)),
             ap_mean=('ap', 'mean'), ap_sd=('ap', 'std'), f1_mean=('f1_cal', 'mean'), f1_sd=('f1_cal', 'std'),
             f1q10_mean=('f1_q10', 'mean'), f1q10_sd=('f1_q10', 'std'), n=('auc', 'size')).reset_index()
summ.to_csv(os.path.join(OUT, 'repeats_summary.csv'), index=False)
# rank stability: how often each model is the best (by AUC) within a repetition
best = d.loc[d.groupby(['rep', 'featureset', 'regime'])['auc'].idxmax()].groupby(['featureset', 'regime', 'model']).size()
json.dump({'R': R, 'best_counts': {f'{a}|{b}|{c}': int(v) for (a, b, c), v in best.items()}}, open(os.path.join(OUT, 'repeats_meta.json'), 'w'), indent=1)
print(summ.to_string())
