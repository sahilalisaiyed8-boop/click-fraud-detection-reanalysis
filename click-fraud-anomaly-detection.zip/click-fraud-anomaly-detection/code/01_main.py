"""Step 1. Main benchmark on the time-ordered split (train 60% / calibration 20% / untouched test 20%).

For every feature set (FULL, NOBOT, BEHAV), information regime (U = contaminated, unlabelled; S = clean-normal) and detector,
the model is fitted on the training split, thresholds are set from training or calibration data only, and all metrics are
computed once on the untouched test split, with percentile-bootstrap 95% CIs (B = 2,000).
Also produces the 'correction ladder' that reconciles the submitted results with the corrected protocol, and two
label-using reference points (single-variable rule and supervised logistic regression).

Usage: python 01_main.py <data.csv> <out_dir>
"""
import json, os, sys, pickle, time
import numpy as np, pandas as pd
from cf_lib import *
from sklearn.linear_model import LogisticRegression

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
df = load(DATA); y = df['is_fraudulent'].values.astype(int)
tr, ca, te = chrono_split(len(df))
QS = [0.01, 0.025, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.35, 0.40, 0.50]
B = 2000
info = {'n': int(len(df)), 'split': {k: {'n': int(len(v)), 'fraud_rate': float(y[v].mean()), 'start': str(df.timestamp[v].min()), 'end': str(df.timestamp[v].max())}
                                      for k, v in [('train', tr), ('calibration', ca), ('test', te)]}}
SC = {}      # scores: (fs, regime, model) -> dict(fit=..., cal=..., test=...)
ROWS = []    # one row per (fs, regime, model)
FIT_INFO = {}


def evaluate(yte, ste, sfit, ycal, scal, seed=0):
    r = {'auc': safe_auc(yte, ste), 'ap': safe_ap(yte, ste), 'p_at_50': precision_at_k(yte, ste, 50), 'p_at_100': precision_at_k(yte, ste, 100)}
    r['auc_ci'] = bootstrap_ci(yte, ste, fast_auc, B=B, seed=seed)
    r['ap_ci'] = bootstrap_ci(yte, ste, fast_ap, B=B, seed=seed)
    # contamination / false-positive-rate thresholds from the data the model was fitted on (no labels)
    r['q'] = {}
    for q in QS:
        t = np.quantile(sfit, 1 - q)
        p, rc, f = prf(yte, ste > t)
        r['q'][str(q)] = {'precision': p, 'recall': rc, 'f1': f, 'flag_rate': float(np.mean(ste > t))}
    # label-calibrated threshold: maximises F1 on the calibration split, applied unchanged to the test split
    t = best_f1_threshold(ycal, scal)
    p, rc, f = prf(yte, ste >= t)
    r['cal'] = {'threshold': t, 'precision': p, 'recall': rc, 'f1': f, 'flag_rate': float(np.mean(ste >= t)),
                'f1_ci': bootstrap_ci(yte, (ste >= t).astype(float), fast_f1, B=B, seed=seed)}
    return r


def run(fs, regime, feats_df, tr_i, ca_i, te_i, models=ORDER, seed=0, orig18=False, tag=None):
    P = Prep(ORIG18 if orig18 else FEATURES[fs], orig18=orig18).fit(feats_df.iloc[tr_i])
    Xtr, Xca, Xte = P.transform(feats_df.iloc[tr_i]), P.transform(feats_df.iloc[ca_i]), P.transform(feats_df.iloc[te_i])
    ytr, yca, yte = y_of(feats_df, tr_i), y_of(feats_df, ca_i), y_of(feats_df, te_i)
    fit_mask = np.ones(len(tr_i), bool) if regime == 'U' else (ytr == 0)
    Xfit = Xtr[fit_mask]
    out = {}
    for k in models:
        m, tfit = timed(MODELS[k](seed).fit, Xfit)
        s_fit, s_cal = m.score(Xfit), m.score(Xca)
        s_te, tsc = timed(m.score, Xte)
        key = (tag or fs, regime, k)
        SC[key] = {'fit': s_fit, 'cal': s_cal, 'test': s_te, 'y_cal': yca, 'y_test': yte}
        ev = evaluate(yte, s_te, s_fit, yca, s_cal)
        ev.update({'featureset': tag or fs, 'regime': regime, 'model': k, 'n_fit': int(len(Xfit)), 'n_features': int(Xfit.shape[1]),
                   'features': P.keep, 'dropped_constant': P.dropped, 'fit_seconds': tfit, 'score_seconds_test': tsc})
        if k == 'DBSCAN':
            ev['dbscan'] = {'eps': m.eps, 'min_samples': m.min_samples, 'n_clusters': m.n_clusters, 'noise_fraction_train': m.noise_fraction}
            yn = (s_te > m.eps).astype(int); p, rc, f = prf(yte, yn)
            ev['dbscan']['native_noise_rule'] = {'precision': p, 'recall': rc, 'f1': f, 'flag_rate': float(yn.mean())}
        ROWS.append(ev); out[k] = ev
        print(f"{tag or fs:6s} {regime} {k:6s} AUC={ev['auc']:.3f} [{ev['auc_ci'][0]:.3f},{ev['auc_ci'][1]:.3f}] AP={ev['ap']:.3f} "
              f"F1cal={ev['cal']['f1']:.3f} F1@q.10={ev['q']['0.1']['f1']:.3f} fit={tfit:.1f}s", flush=True)
    return out


def y_of(d, idx):
    return d['is_fraudulent'].values[idx].astype(int)


# ------------------------------------------------------------------ 1. main grid
for fs in ['FULL', 'NOBOT', 'BEHAV']:
    for regime in ['U', 'S']:
        run(fs, regime, df, tr, ca, te)

# ------------------------------------------------------------------ 2. label-using reference points (not detectors)
ref = {}
yte = y[te]
ref['bot_score_rule'] = {'auc': safe_auc(yte, df['bot_likelihood_score'].values[te]), 'ap': safe_ap(yte, df['bot_likelihood_score'].values[te]),
                         'rule_accuracy_all_5000': float(((df['bot_likelihood_score'] > 0.75).astype(int) == df['is_fraudulent']).mean())}
for fs in ['FULL', 'NOBOT']:
    P = Prep(FEATURES[fs]).fit(df.iloc[tr])
    lr = LogisticRegression(max_iter=5000).fit(P.transform(df.iloc[tr]), y[tr])
    s = lr.predict_proba(P.transform(df.iloc[te]))[:, 1]
    ref[f'supervised_logistic_{fs}'] = {'auc': safe_auc(yte, s), 'ap': safe_ap(yte, s), 'auc_ci': bootstrap_ci(yte, s, fast_auc, B=B)}
info['reference'] = ref
print('reference', json.dumps(ref, default=float))

# ------------------------------------------------------------------ 3. paired comparisons on the test split (FULL)
pairs = {}
for regime in ['U', 'S']:
    res = sorted([r for r in ROWS if r['featureset'] == 'FULL' and r['regime'] == regime], key=lambda r: -r['auc'])
    best = res[0]['model']; sb = SC[('FULL', regime, best)]['test']
    for r in res[1:]:
        so = SC[('FULL', regime, r['model'])]['test']
        pairs[f'{regime}:{best}-{r["model"]}'] = paired_bootstrap_diff(yte, sb, so, fast_auc, B=B)
    # each model against chance (AUC 0.5) is given by its own CI; best U vs best S
for k in ORDER:
    pairs[f'S-U:{k}'] = paired_bootstrap_diff(yte, SC[('FULL', 'S', k)]['test'], SC[('FULL', 'U', k)]['test'], fast_auc, B=B)
    pairs[f'FULL-NOBOT(S):{k}'] = paired_bootstrap_diff(yte, SC[('FULL', 'S', k)]['test'], SC[('NOBOT', 'S', k)]['test'], fast_auc, B=B)
info['paired_auc_differences'] = {k: dict(zip(['mean_diff', 'lo', 'hi', 'p_two_sided'], v)) for k, v in pairs.items()}

# ------------------------------------------------------------------ 4. correction ladder (reconciliation with the submission)
lad = {}
orig = json.load(open(os.path.join(os.path.dirname(OUT.rstrip('/')), 'orig', 'replication_original.json')))
lad['L0_as_submitted_code'] = {k: {'auc': v['auc'], 'f1': v['f1']} for k, v in orig['original_metrics_as_coded'].items()}
lad['L1_scores_oriented_and_AE_label_fixed_in_sample'] = {k: {'auc': orig['diagnostics']['auc_oriented'][k]} for k in ['IF', 'LOF', 'OCSVM', 'AE']}
lad['L1_scores_oriented_and_AE_label_fixed_in_sample']['AE']['f1_at_p90'] = orig['diagnostics']['ae_fixed_label_at_p90']['f1']
# L2: same preprocessing and inputs as submitted (IQR on all data, 18 inputs, AE on normal clicks, others on all clicks) but held-out test
d18 = add_orig18(df); d18['rare_combo'] = d18['rare_combo_full']
keep = iqr_mask(d18, iqr_limits(d18)); d18i = d18[keep].reset_index(drop=True)
tr2, ca2, te2 = chrono_split(len(d18i))
for regime, models in [('U', ['IF', 'LOF', 'OCSVM']), ('S', ['AE'])]:
    run('ORIG18', regime, d18i, tr2, ca2, te2, models=models, orig18=True, tag='ORIG18')
lad['L2_held_out_test_original_inputs_asymmetric'] = {r['model']: {'auc': r['auc'], 'ap': r['ap'], 'f1_q10': r['q']['0.1']['f1']}
                                                     for r in ROWS if r['featureset'] == 'ORIG18'}
lad['L3_symmetric_U_cleaned_inputs_no_IQR'] = {r['model']: {'auc': r['auc'], 'ap': r['ap']} for r in ROWS if r['featureset'] == 'FULL' and r['regime'] == 'U'}
lad['L4_symmetric_S_cleaned_inputs_no_IQR'] = {r['model']: {'auc': r['auc'], 'ap': r['ap']} for r in ROWS if r['featureset'] == 'FULL' and r['regime'] == 'S'}
lad['L5_S_without_bot_likelihood_score'] = {r['model']: {'auc': r['auc'], 'ap': r['ap']} for r in ROWS if r['featureset'] == 'NOBOT' and r['regime'] == 'S'}
info['ladder'] = lad

json.dump({'info': info, 'rows': ROWS}, open(os.path.join(OUT, 'main_results.json'), 'w'), indent=1, default=float)
pickle.dump({'scores': SC, 'tr': tr, 'ca': ca, 'te': te}, open(os.path.join(OUT, 'main_scores.pkl'), 'wb'))
flat = pd.DataFrame([{'featureset': r['featureset'], 'regime': r['regime'], 'model': r['model'], 'auc': r['auc'], 'auc_lo': r['auc_ci'][0], 'auc_hi': r['auc_ci'][1],
                      'ap': r['ap'], 'ap_lo': r['ap_ci'][0], 'ap_hi': r['ap_ci'][1], 'p_at_50': r['p_at_50'], 'p_at_100': r['p_at_100'],
                      'f1_cal': r['cal']['f1'], 'f1_cal_lo': r['cal']['f1_ci'][0], 'f1_cal_hi': r['cal']['f1_ci'][1], 'prec_cal': r['cal']['precision'],
                      'rec_cal': r['cal']['recall'], 'f1_q10': r['q']['0.1']['f1'], 'f1_q25': r['q']['0.25']['f1'], 'n_fit': r['n_fit'],
                      'n_features': r['n_features'], 'fit_s': r['fit_seconds']} for r in ROWS])
flat.to_csv(os.path.join(OUT, 'main_results.csv'), index=False)
print('done')
