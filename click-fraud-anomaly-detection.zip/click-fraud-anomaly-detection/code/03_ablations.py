"""Step 3. Ablations and sensitivity analyses on the time-ordered split (FULL features unless stated).
 (a) IQR outlier filtering (limits from the training split; test split never filtered) vs no filtering
 (b) DBSCAN grid over minPts x eps (eps from percentiles of the training k-distance distribution)
 (c) hyper-parameter sensitivity: LOF k, OCSVM nu and gamma, IF max_samples, AE epochs
 (d) temporal stability: fit on Feb-Jul 2024, evaluate month by month from Aug 2024 to Feb 2025

Usage: python 03_ablations.py <data.csv> <out_dir>
"""
import json, os, sys
import numpy as np, pandas as pd
from sklearn.metrics import silhouette_score
from sklearn.neighbors import NearestNeighbors
from cf_lib import *

DATA, OUT = sys.argv[1], sys.argv[2]
os.makedirs(OUT, exist_ok=True)
df = load(DATA); y = df['is_fraudulent'].values.astype(int)
tr, ca, te = chrono_split(len(df))
RES = {}

# ------------------------------------------------------------------ (a) IQR filtering
full_lim = iqr_limits(df); full_keep = iqr_mask(df, full_lim)
RES['iqr_full_sample'] = {'removed': int((~full_keep).sum()), 'fraud_rate_removed': float(y[~full_keep].mean()),
                          'fraud_rate_kept': float(y[full_keep].mean()),
                          'removed_by_variable': {c: int(((df[c] < lo) | (df[c] > hi)).sum()) for c, (lo, hi) in full_lim.items()},
                          'limits': {c: [float(lo), float(hi)] for c, (lo, hi) in full_lim.items()}}
lim = iqr_limits(df.iloc[tr]); keep_tr = iqr_mask(df.iloc[tr], lim)
RES['iqr_train'] = {'removed': int((~keep_tr).sum()), 'fraud_rate_removed': float(y[tr][~keep_tr].mean()),
                    'test_points_outside_limits': int((~iqr_mask(df.iloc[te], lim)).sum()),
                    'fraud_rate_test_outside': float(y[te][~iqr_mask(df.iloc[te], lim)].mean())}
iqr_rows = []
for filt in [False, True]:
    tr_use = tr[keep_tr] if filt else tr
    P = Prep(FEATURES['FULL']).fit(df.iloc[tr_use]); Xtr, Xte = P.transform(df.iloc[tr_use]), P.transform(df.iloc[te])
    for regime in ['U', 'S']:
        Xfit = Xtr if regime == 'U' else Xtr[y[tr_use] == 0]
        for k in ORDER:
            s = MODELS[k](0).fit(Xfit).score(Xte)
            iqr_rows.append({'iqr_filter': filt, 'regime': regime, 'model': k, 'auc': safe_auc(y[te], s), 'ap': safe_ap(y[te], s)})
            print('IQR', filt, regime, k, round(iqr_rows[-1]['auc'], 3), flush=True)
RES['iqr_ablation'] = iqr_rows

# ------------------------------------------------------------------ (b) DBSCAN grid
P = Prep(FEATURES['FULL']).fit(df.iloc[tr]); Xtr, Xte = P.transform(df.iloc[tr]), P.transform(df.iloc[te])
grid = []
for regime in ['U', 'S']:
    Xfit = Xtr if regime == 'U' else Xtr[y[tr] == 0]
    for mp in [5, 12, 24, 48]:
        kd = NearestNeighbors(n_neighbors=mp).fit(Xfit).kneighbors(Xfit)[0][:, -1]
        eps_list = [('orig', 0.5)] + [(f'p{p}', float(np.percentile(kd, p))) for p in [10, 25, 50, 75, 90, 95, 99]] + [('knee', DBSCAN_.knee_eps(Xfit, mp))]
        for lab, eps in eps_list:
            m = DBSCAN_(0, eps=eps, min_samples=mp).fit(Xfit)
            s = m.score(Xte); yn = (s > eps).astype(int)
            p, r, f = prf(y[te], yn)
            sil = None
            labs = m.train_labels; nn = labs >= 0
            if m.n_clusters >= 2 and nn.sum() > 10:
                sil = float(silhouette_score(Xfit[nn], labs[nn], sample_size=min(2000, int(nn.sum())), random_state=0))
            grid.append({'regime': regime, 'min_samples': mp, 'eps_rule': lab, 'eps': eps, 'n_clusters': m.n_clusters,
                         'noise_fraction_train': m.noise_fraction, 'silhouette_non_noise': sil, 'test_auc_distance_score': safe_auc(y[te], s),
                         'test_ap_distance_score': safe_ap(y[te], s), 'test_noise_rate': float(yn.mean()), 'precision_noise_rule': p, 'recall_noise_rule': r,
                         'f1_noise_rule': f})
            print('DBSCAN', regime, mp, lab, round(eps, 2), m.n_clusters, round(m.noise_fraction, 3), round(grid[-1]['test_auc_distance_score'], 3), flush=True)
RES['dbscan_grid'] = grid

# ------------------------------------------------------------------ (c) hyper-parameter sensitivity
hp = []
def add(regime, model, param, value, s):
    hp.append({'regime': regime, 'model': model, 'param': param, 'value': str(value), 'auc': safe_auc(y[te], s), 'ap': safe_ap(y[te], s)})
    print('HP', regime, model, param, value, round(hp[-1]['auc'], 3), flush=True)
for regime in ['U', 'S']:
    Xfit = Xtr if regime == 'U' else Xtr[y[tr] == 0]
    for kk in [5, 10, 20, 50, 100, 200]:
        add(regime, 'LOF', 'n_neighbors', kk, LOF_(0, k=kk).fit(Xfit).score(Xte))
    for nu in [0.01, 0.05, 0.1, 0.25, 0.5]:
        add(regime, 'OCSVM', 'nu', nu, OCSVM_(0, nu=nu).fit(Xfit).score(Xte))
    for g in [0.01, 0.03, 'scale', 0.3, 1.0]:
        add(regime, 'OCSVM', 'gamma', g, OCSVM_(0, gamma=g).fit(Xfit).score(Xte))
    for ms in [64, 256, 1024, 1.0]:
        add(regime, 'IF', 'max_samples', ms, IF_(0, max_samples=ms).fit(Xfit).score(Xte))
    for ne in [50, 100, 500]:
        add(regime, 'IF', 'n_estimators', ne, IF_(0, n_estimators=ne).fit(Xfit).score(Xte))
    for ep in [10, 30, 100]:
        add(regime, 'AE', 'epochs', ep, AE_(0, epochs=ep).fit(Xfit).score(Xte))
    for ep in [10, 30, 100]:
        add(regime, 'DSVDD', 'epochs', ep, DSVDD_(0, epochs=ep).fit(Xfit).score(Xte))
    for mr in [0.15, 0.25, 0.5]:
        add(regime, 'TRF', 'mask_rate', mr, TRF_(0, mask_rate=mr).fit(Xfit).score(Xte))
RES['hyperparameters'] = hp

# ------------------------------------------------------------------ (d) temporal stability
t_end = pd.Timestamp('2024-08-01')
trm = np.where(df['timestamp'] < t_end)[0]
later = df['timestamp'] >= t_end
months = df.loc[later, 'timestamp'].dt.to_period('M').astype(str)
P = Prep(FEATURES['FULL']).fit(df.iloc[trm]); Xtrm = P.transform(df.iloc[trm])
ts_rows = []
for regime in ['U', 'S']:
    Xfit = Xtrm if regime == 'U' else Xtrm[y[trm] == 0]
    for k in ORDER:
        m = MODELS[k](0).fit(Xfit)
        for mo in sorted(months.unique()):
            idx = months.index[months == mo].values
            s = m.score(P.transform(df.iloc[idx]))
            ts_rows.append({'regime': regime, 'model': k, 'month': mo, 'n': int(len(idx)), 'fraud_rate': float(y[idx].mean()), 'auc': safe_auc(y[idx], s)})
        print('TIME', regime, k, [round(r['auc'], 2) for r in ts_rows if r['regime'] == regime and r['model'] == k], flush=True)
RES['temporal'] = {'train_period': [str(df.timestamp[trm].min()), str(df.timestamp[trm].max())], 'n_train': int(len(trm)), 'rows': ts_rows}
json.dump(RES, open(os.path.join(OUT, 'ablations.json'), 'w'), indent=1, default=float)
print('done')
