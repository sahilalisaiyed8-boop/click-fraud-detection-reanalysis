"""Step 4. Feature-space structure and top-ranked clicks.
 (a) neighbourhood mixing in the ORIGINAL standardised feature space (not in t-SNE space): for each click, the share of
     fraudulent clicks among its k nearest neighbours; enrichment relative to the base rate; leave-one-out kNN AUC
 (b) t-SNE of the untouched test split (FULL and NOBOT), kept for display only, coloured by ground truth
 (c) top-k analysis with a rank-normalised consensus score (each model's oriented score -> percentile rank within the
     test split -> mean across models), with hypergeometric p-values against the base rate

Usage: python 04_structure.py <data.csv> <main_scores.pkl> <out_dir>
"""
import json, os, sys, pickle
import numpy as np, pandas as pd
from scipy.stats import rankdata, hypergeom
from sklearn.neighbors import NearestNeighbors
from sklearn.manifold import TSNE
from cf_lib import *

DATA, SCP, OUT = sys.argv[1], sys.argv[2], sys.argv[3]
os.makedirs(OUT, exist_ok=True)
df = load(DATA); y = df['is_fraudulent'].values.astype(int)
tr, ca, te = chrono_split(len(df))
RES = {'base_rate_all': float(y.mean()), 'base_rate_test': float(y[te].mean())}

# ------------------------------------------------------------------ (a) neighbourhood mixing
mix = []
spaces = {'FULL': FEATURES['FULL'], 'NOBOT': FEATURES['NOBOT'], 'BOT_ONLY': ['bot_likelihood_score']}
for name, feats in spaces.items():
    P = Prep(feats).fit(df.iloc[tr]); X = P.transform(df)
    for k in [5, 10, 20]:
        nn = NearestNeighbors(n_neighbors=k + 1).fit(X)
        ind = nn.kneighbors(X, return_distance=False)[:, 1:]          # exclude the click itself
        frac = y[ind].mean(1)
        mix.append({'space': name, 'k': k, 'n_features': int(X.shape[1]), 'fraud_neighbour_share_fraud': float(frac[y == 1].mean()),
                    'fraud_neighbour_share_normal': float(frac[y == 0].mean()), 'base_rate': float(y.mean()),
                    'enrichment_fraud': float(frac[y == 1].mean() / y.mean()), 'loo_knn_auc': safe_auc(y, frac),
                    'share_fraud_with_majority_fraud_neighbours': float((frac[y == 1] > 0.5).mean())})
        print(mix[-1], flush=True)
RES['neighbourhood_mixing'] = mix

# ------------------------------------------------------------------ (b) t-SNE (display only) and mixing in the embedding
emb = {}
for name in ['FULL', 'NOBOT']:
    P = Prep(FEATURES[name]).fit(df.iloc[tr]); Xte = P.transform(df.iloc[te])
    E = TSNE(n_components=2, perplexity=30, init='pca', random_state=42, learning_rate='auto').fit_transform(Xte)
    emb[name] = E
    ind = NearestNeighbors(n_neighbors=11).fit(E).kneighbors(E, return_distance=False)[:, 1:]
    frac = y[te][ind].mean(1)
    RES.setdefault('tsne_mixing_k10', {})[name] = {'fraud_neighbour_share_fraud': float(frac[y[te] == 1].mean()),
                                                   'fraud_neighbour_share_normal': float(frac[y[te] == 0].mean()), 'loo_knn_auc': safe_auc(y[te], frac)}

# ------------------------------------------------------------------ (c) top-k with rank-normalised consensus
S = pickle.load(open(SCP, 'rb'))['scores']
yte = y[te]; N = len(te); K = int(yte.sum())
def pct(s):
    s = np.asarray(s, float); s = np.where(np.isfinite(s), s, np.nanmax(s[np.isfinite(s)]) + 1)
    return rankdata(s) / len(s)
top = {}
cons = {}
for regime in ['U', 'S']:
    R = np.column_stack([pct(S[('FULL', regime, k)]['test']) for k in ORDER])
    c = R.mean(1); cons[regime] = c
    o = np.argsort(-c, kind='mergesort')
    res = {'consensus_auc': safe_auc(yte, c), 'consensus_ap': safe_ap(yte, c)}
    for kk in [20, 50, 100, 250]:
        hits = int(yte[o[:kk]].sum())
        res[f'top{kk}'] = {'fraud': hits, 'precision': hits / kk, 'p_value_hypergeom': float(hypergeom.sf(hits - 1, N, K, kk))}
    t20 = df.iloc[te].iloc[o[:20]]
    res['top20_profile'] = {'bot_mean': float(t20['bot_likelihood_score'].mean()), 'bot_sd': float(t20['bot_likelihood_score'].std()),
                            'vpn': int(t20['VPN_usage'].sum()), 'proxy': int(t20['proxy_usage'].sum()),
                            'reputation': t20['device_ip_reputation'].value_counts().to_dict(),
                            'click_duration_median': float(t20['click_duration'].median())}
    # per-model precision at 20
    res['per_model_p_at_20'] = {k: precision_at_k(yte, S[('FULL', regime, k)]['test'], 20) for k in ORDER}
    top[regime] = res
    print(regime, json.dumps(res, default=float), flush=True)
RES['topk'] = top
RES['test_population_profile'] = {'bot_mean': float(df.iloc[te]['bot_likelihood_score'].mean()), 'vpn_share': float(df.iloc[te]['VPN_usage'].mean()),
                                  'proxy_share': float(df.iloc[te]['proxy_usage'].mean()),
                                  'bad_reputation_share': float((df.iloc[te]['device_ip_reputation'] == 'Bad').mean())}
json.dump(RES, open(os.path.join(OUT, 'structure.json'), 'w'), indent=1, default=float)
pickle.dump({'tsne': emb, 'y_test': yte, 'consensus': cons, 'bot_test': df['bot_likelihood_score'].values[te]}, open(os.path.join(OUT, 'structure.pkl'), 'wb'))
print('done')
