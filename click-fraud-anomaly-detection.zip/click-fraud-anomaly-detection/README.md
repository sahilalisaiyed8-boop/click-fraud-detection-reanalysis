# Protocol-controlled evaluation of anomaly detectors for click-fraud detection

Code, result files and figures for the manuscript *"Unsupervised Click Fraud Detection in Digital Advertising: A Protocol-Controlled
Evaluation of Anomaly Detection Models"* (Measurement: Digitalization, MEADIG-D-26-00099, revision 1).

Every number, table and figure in the revised manuscript is produced by the scripts in `code/` from the public data file
`data/click_fraud_dataset.csv` (5,000 clicks, 21 columns). The result files and logs behind the manuscript are included in
`outputs/`, so every reported number can be checked without re-running anything.

## Repository layout

| Folder / file | Content |
|---|---|
| `code/` | Analysis scripts (`00` to `07`) and shared library `cf_lib.py` |
| `data/click_fraud_dataset.csv` | The public click-fraud data set analysed in the paper (unchanged) |
| `outputs/` | Result files (JSON, CSV, pickles) and logs of every step, as used in the manuscript |
| `outputs/splits/split_indices.csv` | Split assignment of every click, in the time order used by all scripts |
| `figures/` | Figures 1 to 10 as PNG (300 dpi), TIFF (600 dpi) and vector PDF |
| `run_all.sh` | Re-runs the full pipeline (about 90 min on 2 vCPU) into `outputs_rerun/` |
| `make_figures_only.sh` | Redraws the ten figures from `outputs/` (about 1 min) into `figures_rerun/` |

## Quick start

    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    bash make_figures_only.sh      # figures from the shipped results
    bash run_all.sh                # complete re-run from the raw data

Accuracy results are seeded and reproducible; timings (step 5) depend on the machine.

## Requirements
Python 3.10+ (tested with 3.13), numpy, pandas, scipy, scikit-learn 1.9.1, tensorflow(-cpu) 2.20.0, pyod 3.6.7, matplotlib.

    pip install "scikit-learn==1.9.1" "tensorflow-cpu==2.20.0" "pyod==3.6.7" pandas scipy matplotlib

## Run order (DATA = path to click_fraud_dataset.csv, OUT = output folder)

| Step | Script | What it does | Time (2 vCPU) |
|---|---|---|---|
| 0 | `00_replicate_original.py DATA OUT/orig` | Re-runs the notebook of the submitted version exactly and documents its errors (score orientation, autoencoder label code, raw-score averaging, constant inputs, DBSCAN noise) | 1 min |
| 0b | `00b_data_audit.py DATA OUT/audit` | Data audit: labelling rule (label = 1 iff bot_likelihood_score > 0.75), distributions, independence tests | seconds |
| 1 | `01_main.py DATA OUT/main` | Time-ordered 60/20/20 split; 3 feature sets x 2 regimes x 8 detectors; thresholds; bootstrap CIs; paired tests; reference points; correction ladder | 10 min |
| 2 | `02_repeats.py DATA OUT/repeats 10` | 10 stratified random splits with different seeds | 35 min |
| 3 | `03_ablations.py DATA OUT/ablations` | IQR filtering, DBSCAN grid, hyper-parameter sensitivity, monthly stability | 15 min |
| 3b | `03b_dbscan_clusters.py DATA OUT/ablations/ablations.json OUT/ablations` | What the DBSCAN clusters of the grid represent (size, fraud rate, separating input) | 1 min |
| 4 | `04_structure.py DATA OUT/main/main_scores.pkl OUT/structure` | Neighbourhood mixing in feature space, t-SNE, rank-normalised top-k analysis | 2 min |
| 5 | `05_timing.py DATA OUT/timing` | Fit time and scoring throughput up to 300,000 training clicks; one untimed warm-up per detector, medians of up to five repetitions (run alone) | 25 min |
| 6 | `06_figures.py DATA OUT FIGDIR` | All ten figures (PNG 300 dpi, TIFF 600 dpi, vector PDF) | 1 min |

`cf_lib.py` holds the shared code: data loading, leakage-free feature construction (fitted on the training split only),
splits, the eight detectors (all scores oriented so that higher = more anomalous), metrics and bootstrap routines.

## Key definitions
* Regime U: detectors fitted on all training clicks without labels (unsupervised, contaminated).
* Regime S: detectors fitted on the training clicks labelled normal (one-class / semi-supervised).
* Feature sets: FULL (12 inputs), NOBOT (FULL without bot_likelihood_score), BEHAV (7 behavioural and timing inputs).
* Seeds: model seed 0 on the time-ordered split; split seeds 1000-1009 and model seeds 0-9 for the repeated splits; t-SNE random_state 42; bootstrap seed 0.

## Data
`data/click_fraud_dataset.csv` is the public data set used by the original submission. Its label rule
(label = 1 iff bot_likelihood_score > 0.75) is documented by `00b_data_audit.py`. Please cite the original data source when reusing it.

## License
Code: MIT (see `LICENSE`). The data file keeps the terms of its original source.
