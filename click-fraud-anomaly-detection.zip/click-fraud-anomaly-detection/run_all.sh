#!/usr/bin/env bash
# Re-creates every result and figure from data/click_fraud_dataset.csv (about 90 minutes on 2 vCPU).
# Usage: bash run_all.sh [output_dir]      (default: ./outputs_rerun, so the shipped outputs/ are not overwritten)
set -euo pipefail
cd "$(dirname "$0")/code"
DATA=../data/click_fraud_dataset.csv
OUT=${1:-../outputs_rerun}
mkdir -p "$OUT"
python 00_replicate_original.py $DATA $OUT/orig
python 00b_data_audit.py        $DATA $OUT/audit
python 01_main.py               $DATA $OUT/main
python 02_repeats.py            $DATA $OUT/repeats 10
python 03_ablations.py          $DATA $OUT/ablations
python 03b_dbscan_clusters.py   $DATA $OUT/ablations/ablations.json $OUT/ablations
python 04_structure.py          $DATA $OUT/main/main_scores.pkl $OUT/structure
python 05_timing.py             $DATA $OUT/timing        # run alone: it measures wall-clock time
python 07_export_splits.py      $DATA $OUT/splits
python 06_figures.py            $DATA $OUT ../figures_rerun
